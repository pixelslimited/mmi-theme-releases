<?php
/**
 * The footer for the theme.
 *
 * @package MMI_Technologies
 */
?>
	<footer class="site-footer">
		<div class="container footer-grid">
			<div class="footer-col footer-about">
				<div class="footer-logo-lockup">
					<?php
					mmi_logo();
					?>
					<span class="footer-site-title"><?php bloginfo( 'name' ); ?></span>
				</div>
				<p><?php bloginfo( 'description' ); ?> MMI Technologies Ltd provides solar power solutions, CCTV &amp; security, networking &amp; cyber security, IT &amp; payment systems, construction &amp; renovation, import &amp; supply, consultancy, and design &amp; printing services across Nigeria.</p>
				<div class="footer-social">
					<a href="<?php echo esc_url( mmi_whatsapp_url() ); ?>" target="_blank" rel="noopener" aria-label="WhatsApp"><?php mmi_icon( 'phone' ); ?></a>
				</div>
			</div>

			<div class="footer-col">
				<h4 class="footer-widget-title"><?php esc_html_e( 'Quick Links', 'mmi-tech' ); ?></h4>
				<?php
				if ( has_nav_menu( 'footer' ) ) {
					wp_nav_menu( array(
						'theme_location' => 'footer',
						'container'      => false,
						'menu_class'     => 'footer-menu',
						'fallback_cb'    => false,
					) );
				} else {
					?>
					<ul class="footer-menu">
						<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'mmi-tech' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>"><?php esc_html_e( 'About', 'mmi-tech' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'Services', 'mmi-tech' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/products/' ) ); ?>"><?php esc_html_e( 'Products', 'mmi-tech' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/projects/' ) ); ?>"><?php esc_html_e( 'Projects', 'mmi-tech' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact Us', 'mmi-tech' ); ?></a></li>
					</ul>
					<?php
				}
				?>
			</div>

			<div class="footer-col">
				<h4 class="footer-widget-title"><?php esc_html_e( 'Our Services', 'mmi-tech' ); ?></h4>
				<ul class="footer-menu">
					<li><?php esc_html_e( 'Solar Power Solutions', 'mmi-tech' ); ?></li>
					<li><?php esc_html_e( 'CCTV, Networking &amp; Security', 'mmi-tech' ); ?></li>
					<li><?php esc_html_e( 'IT &amp; Payment Systems', 'mmi-tech' ); ?></li>
					<li><?php esc_html_e( 'Construction &amp; Renovation', 'mmi-tech' ); ?></li>
					<li><?php esc_html_e( 'Import &amp; Supply', 'mmi-tech' ); ?></li>
					<li><?php esc_html_e( 'Consultancy &amp; Technical Support', 'mmi-tech' ); ?></li>
					<li><?php esc_html_e( 'Design, Printing &amp; Publishing', 'mmi-tech' ); ?></li>
				</ul>
			</div>

			<div class="footer-col">
				<h4 class="footer-widget-title"><?php esc_html_e( 'Get in Touch', 'mmi-tech' ); ?></h4>
				<ul class="footer-contact">
					<li><a href="tel:+2347019448554"><?php mmi_icon( 'phone' ); ?> +234 701 944 8554</a></li>
					<li><a href="tel:+2347076111066"><?php mmi_icon( 'phone' ); ?> +234 707 611 1066</a></li>
					<li><a href="tel:+2347071751117"><?php mmi_icon( 'phone' ); ?> +234 707 175 1117</a></li>
					<li><a href="mailto:mmitechnologies1@gmail.com"><?php mmi_icon( 'mail' ); ?> mmitechnologies1@gmail.com</a></li>
				</ul>
				<?php if ( is_active_sidebar( 'footer-widgets' ) ) : ?>
					<?php dynamic_sidebar( 'footer-widgets' ); ?>
				<?php endif; ?>
			</div>
		</div>

		<div class="footer-bottom">
			<div class="container footer-bottom-inner">
				<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'mmi-tech' ); ?>
					<?php
					// A deliberately low-key link so staff/admins can always
					// find their way to the dashboard without needing to
					// remember or bookmark its address — kept out of the
					// main menus by design, but not hidden entirely. Only
					// rendered once the "Staff Login" page actually exists
					// (mmi_get_staff_login_url() otherwise falls back to the
					// homepage, which would make a misleading link).
					if ( function_exists( 'mmi_get_staff_login_url' ) ) {
						$mmi_staff_login_url = mmi_get_staff_login_url();
						if ( $mmi_staff_login_url && trailingslashit( $mmi_staff_login_url ) !== trailingslashit( home_url( '/' ) ) ) {
							echo ' &middot; <a href="' . esc_url( $mmi_staff_login_url ) . '" class="footer-staff-link">' . esc_html__( 'Staff Login', 'mmi-tech' ) . '</a>';
						}
					}
					?>
				</p>
			</div>
		</div>
	</footer>

<?php wp_footer(); ?>
</body>
</html>
