<?php
/**
 * MMI Technologies Ltd theme bootstrap.
 *
 * @package MMI_Technologies
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'MMI_THEME_VERSION', '1.9.3' );
define( 'MMI_THEME_DIR', get_template_directory() );
define( 'MMI_THEME_URI', get_template_directory_uri() );

/**
 * Theme setup: supports, menus, image sizes.
 * NOTE: deliberately NO automatic page/menu/image creation here — that
 * automation was removed after it caused repeated activation crashes on
 * resource-constrained shared hosting. Setup is documented as a manual,
 * standard-WordPress workflow in README.txt.
 */
function mmi_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 80,
		'width'       => 240,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );

	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'mmi-tech' ),
		'footer'  => __( 'Footer Menu', 'mmi-tech' ),
	) );

	add_image_size( 'mmi-card', 640, 480, true );
	add_image_size( 'mmi-gallery-thumb', 160, 160, true );
	add_image_size( 'mmi-hero', 1600, 900, true );
}
add_action( 'after_setup_theme', 'mmi_setup' );

/**
 * Enqueue front-end styles and scripts.
 */
function mmi_enqueue_assets() {
	wp_enqueue_style( 'mmi-google-fonts', 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600;700;800&family=Inter:wght@400;500;600;700;800&display=swap', array(), null );
	wp_enqueue_style( 'mmi-main', MMI_THEME_URI . '/assets/css/main.css', array(), MMI_THEME_VERSION );
	wp_enqueue_style( 'mmi-modern', MMI_THEME_URI . '/assets/css/modern.css', array( 'mmi-main' ), MMI_THEME_VERSION );
	wp_enqueue_script( 'mmi-modern-js', MMI_THEME_URI . '/assets/js/modern.js', array(), MMI_THEME_VERSION, true );
	wp_enqueue_script( 'mmi-main-js', MMI_THEME_URI . '/assets/js/main.js', array(), MMI_THEME_VERSION, true );

	if ( is_page_template( array( 'template-staff-login.php', 'template-staff-dashboard.php' ) ) ) {
		wp_enqueue_style( 'mmi-dashboard', MMI_THEME_URI . '/assets/css/dashboard.css', array( 'mmi-main' ), MMI_THEME_VERSION );
	}

	if ( is_singular() ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'mmi_enqueue_assets' );

/**
 * Includes.
 */
require MMI_THEME_DIR . '/inc/customizer.php';
require MMI_THEME_DIR . '/inc/custom-post-types.php';
require MMI_THEME_DIR . '/inc/template-functions.php';
require MMI_THEME_DIR . '/inc/smtp-settings.php';
require MMI_THEME_DIR . '/inc/forms-handler.php';
require MMI_THEME_DIR . '/inc/staff-role.php';
require MMI_THEME_DIR . '/inc/enquiry-dashboard.php';
require MMI_THEME_DIR . '/inc/updater.php';
require MMI_THEME_DIR . '/inc/setup-pages.php';

/**
 * Register widget areas (footer columns use static markup, but a sidebar is
 * provided for anyone who wants to add widgets later without editing PHP).
 */
function mmi_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Footer Widgets', 'mmi-tech' ),
		'id'            => 'footer-widgets',
		'before_widget' => '<div class="footer-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="footer-widget-title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'mmi_widgets_init' );

/**
 * Sensible excerpt length + "read more" string for anywhere the_excerpt() is used.
 */
add_filter( 'excerpt_length', function() {
	return 24;
} );
add_filter( 'excerpt_more', function() {
	return '&hellip;';
} );

/**
 * Template loader: map our custom "template-*.php" front-page/page templates
 * so they show up nicely in Page Attributes without extra Template Name
 * juggling headaches — each file below already declares its own
 * "Template Name:" header, which is the standard WordPress mechanism, so no
 * extra code is required here. This comment exists purely for maintainers.
 */

/**
 * Body classes: add a class for the active custom page template so CSS can
 * target specific pages without relying on IDs that change if the page is
 * recreated.
 */
add_filter( 'body_class', function( $classes ) {
	if ( is_page_template( 'template-contact.php' ) ) {
		$classes[] = 'mmi-page-contact';
	}
	if ( is_404() ) {
		$classes[] = 'mmi-page-404';
	}
	return $classes;
} );


/**
 * Logo: the logo set in Appearance > Customize wins; otherwise the bundled MMI logo is used.
 */
function mmi_logo() {
	if ( has_custom_logo() ) {
		the_custom_logo();
		return;
	}
	printf(
		'<a href="%s" class="custom-logo-link" rel="home"><img src="%s" class="custom-logo" width="256" height="256" alt="%s"></a>',
		esc_url( home_url( '/' ) ),
		esc_url( MMI_THEME_URI . '/assets/images/mmi-logo.png' ),
		esc_attr( get_bloginfo( 'name' ) )
	);
}

/* Browser tab icon: the Site Icon set in Customize wins; otherwise the bundled one. */
add_action( 'wp_head', function () {
	if ( has_site_icon() ) { return; }
	echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( MMI_THEME_URI . '/assets/images/mmi-icon-32.png' ) . '">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( MMI_THEME_URI . '/assets/images/mmi-icon-192.png' ) . '">' . "\n";
}, 5 );
