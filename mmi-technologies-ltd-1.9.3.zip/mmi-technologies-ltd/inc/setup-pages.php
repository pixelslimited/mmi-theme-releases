<?php
/**
 * ONE-TIME SITE SETUP
 * Runs once, the first time this version loads: makes sure the pages the menu points to exist and are live,
 * and replaces the stock WordPress site title/tagline. Anything already set up is left as it is.
 * Pages that were trashed are restored (with their old content); drafts are published; missing ones are created.
 * It never runs again, so pages deleted on purpose later stay deleted.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', function () {
	if ( get_option( 'mmi_pages_seeded' ) ) { return; }
	update_option( 'mmi_pages_seeded', MMI_THEME_VERSION, false ); // set first so a failure can never loop

	$pages = array(
		'about'    => array( 'About', 'template-about.php' ),
		'services' => array( 'Services', 'template-services.php' ),
		'products' => array( 'Products', 'template-products.php' ),
		'projects' => array( 'Projects', 'template-projects.php' ),
		'contact'  => array( 'Contact Us', 'template-contact.php' ),
	);
	$statuses = array( 'publish', 'draft', 'pending', 'private', 'future', 'trash' );

	foreach ( $pages as $slug => $def ) {
		$found = get_posts( array( 'post_type' => 'page', 'name' => $slug, 'post_status' => $statuses, 'numberposts' => 1 ) );
		if ( $found ) {
			$p = $found[0];
			if ( 'trash' === $p->post_status ) { wp_untrash_post( $p->ID ); }
			if ( 'publish' !== get_post_status( $p->ID ) ) { wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'publish' ) ); }
			if ( ! get_post_meta( $p->ID, '_wp_page_template', true ) || 'default' === get_post_meta( $p->ID, '_wp_page_template', true ) ) {
				update_post_meta( $p->ID, '_wp_page_template', $def[1] );
			}
			continue;
		}
		wp_insert_post( array(
			'post_type'   => 'page',
			'post_status' => 'publish',
			'post_title'  => $def[0],
			'post_name'   => $slug,
			'post_author' => 1,
			'meta_input'  => array( '_wp_page_template' => $def[1] ),
		) );
	}

	if ( 'My Blog' === get_option( 'blogname' ) ) { update_option( 'blogname', 'MMI Technologies Ltd' ); }
	if ( 'My WordPress Blog' === get_option( 'blogdescription' ) ) { update_option( 'blogdescription', 'Innovation is our tradition' ); }

	flush_rewrite_rules( false );
}, 20 );
