=== MMI Technologies Ltd — WordPress Theme ===
Version: 1.9.3

WHAT'S NEW IN 1.9.3: one-time setup on first load: restores or creates About, Services, Products, Projects and Contact pages, and replaces the stock site title and tagline. Pages deleted later stay deleted.
WHAT'S NEW IN 1.9.2: MMI logo and browser-tab icon bundled (a logo set in Customize still wins).
WHAT'S NEW IN 1.9.1: on-site updater (Appearance > Theme updates and Dashboard > Updates). New versions are published automatically as signed zips; a copy of the current theme is saved before each update and can be restored.
WHAT'S NEW IN 1.9.0 (new look): dark navy hero with drifting light, floating service cards and a service ticker; bento-style services grid; connected 'How we work' steps; card hover effects; glass header that gains a shadow on scroll; Bricolage Grotesque headings; fine paper grain; one orange accent (main buttons, active menu line, one highlight per area) on two blues. Motion switches off for visitors who ask for reduced motion. After installing, clear SpeedyCache and hard-refresh.

A custom WordPress theme built for MMI Technologies Ltd (mmitechnologies.net).

-----------------------------------------------------------------------------
URGENT — READ THIS FIRST IF PAGES ARE SHOWING "404 Not Found"
-----------------------------------------------------------------------------

If every page except the homepage shows a plain black "404 Not Found — The
resource requested could not be found on this server!" page (mentioning
"LiteSpeed Web Server"), this is NOT a theme bug and installing this update
will not fix it on its own — that plain, unstyled page is your web SERVER
saying it, before WordPress ever gets a chance to run. (If it were a WordPress
problem, you'd see this theme's own styled "Page Not Found" screen instead,
with the site header, footer and a search box.)

This happens when WordPress's "pretty" page links (yoursite.com/about/)
aren't being handed off to WordPress by the server any more — almost always
because the permalink rewrite rules need refreshing, or the .htaccess file
that does that handoff is missing or was overwritten. Fix:

  1. Log into wp-admin and go to Settings > Permalinks.
  2. Without changing anything, just click "Save Changes" at the bottom.
     This alone fixes it most of the time.
  3. Visit a non-homepage URL (e.g. /about/) to check.
  4. Still broken? Open your hosting File Manager (or FTP) and look in the
     same folder as wp-config.php for a file named .htaccess. It should
     contain a block that starts with "# BEGIN WordPress" and ends with
     "# END WordPress". If that file is missing, or that block is missing
     from it, create/edit .htaccess and paste in:

       # BEGIN WordPress
       <IfModule mod_rewrite.c>
       RewriteEngine On
       RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
       RewriteBase /
       RewriteRule ^index\.php$ - [L]
       RewriteCond %{REQUEST_FILENAME} !-f
       RewriteCond %{REQUEST_FILENAME} !-d
       RewriteRule . /index.php [L]
       </IfModule>
       # END WordPress

     Save it, then repeat step 3.
  5. Still broken? Temporarily deactivate the SpeedyCache plugin and test
     again — some caching plugins rewrite .htaccess themselves and can
     conflict with it. If that fixes it, re-enable SpeedyCache afterwards
     and look for a "regenerate .htaccess" option in its settings.
  6. Still broken after all of the above? Contact your hosting provider and
     ask them to confirm mod_rewrite is enabled and .htaccess overrides are
     allowed for your domain — this is a one-line fix on their end.

Every page's Template setting and this theme's own code are unaffected by
any of this — there is nothing to reinstall or reconfigure in the theme
itself for this specific issue.

-----------------------------------------------------------------------------
WHAT'S NEW IN 1.8.2
-----------------------------------------------------------------------------

1. New: a consistent "Apple Glass" look and feel, with proper motion rules.
   The sticky header, the mobile menu panel, the WhatsApp button and the
   "Page Not Found" card now use a frosted-glass (blurred, translucent)
   surface instead of a flat solid one — the same visual language used
   across modern Apple interfaces. Every hover, click, menu open/close and
   notice popping in now moves on one consistent, shared timing system
   instead of many slightly-different speeds, so the site feels like one
   coherent piece of motion rather than a patchwork. Visitors who have
   "Reduce Motion" turned on at the system level automatically get a
   near-instant, still-functional version with the movement stripped out.
   Cards (services, products, projects, "Why Choose Us") now gently fade
   and lift into view as you scroll down the page.

2. New: skeleton loading, shown only when it actually helps.
   On a normal connection, images simply load — no skeleton flash, because
   on a fast connection a skeleton placeholder would just be visual noise
   that disappears a moment later. The theme now detects when a visitor is
   on a slow or data-saver connection and, only then, shows a shimmering
   skeleton placeholder over product/project images and gallery thumbnails
   while they load. Separately — and always, regardless of connection
   speed — every form on the site (Contact, Staff Login, and every action
   in the Staff Dashboard) now shows an immediate loading spinner on its
   button the moment it's submitted, so there's instant confirmation the
   tap registered, and it can't accidentally be submitted twice.

3. Easier to find the Staff Dashboard.
   The Staff Login page is still deliberately left out of the main menu (so
   visitors don't stumble onto it), but a small "Staff Login" link has been
   added next to the copyright line in the footer of every page, so you and
   your team always have a way to reach it without needing to remember or
   bookmark its address. (This link only appears once a "Staff Login" page
   using the "Staff Login" template has actually been created — see STEP 1
   in MANUAL SETUP below if you haven't created the 8 pages yet.)

4. Reminder: enquiry emails still need SMTP set up.
   If enquiries aren't reaching your inbox yet, this is expected until the
   one-time SMTP setup below is completed — every enquiry is still always
   saved to Dashboard > Enquiries and the Staff Dashboard either way, so
   nothing is lost in the meantime. See "EMAIL SETUP" below.

-----------------------------------------------------------------------------
WHAT'S NEW IN 1.8.1
-----------------------------------------------------------------------------

1. Bug fix: WhatsApp button floating off-screen on mobile.
   On narrow phone screens, a few grid layouts (Services, Products, Projects,
   Core Values sections) had a fixed minimum column width that couldn't
   shrink to fit the screen, which pushed the whole page slightly wider than
   the visible area. On some mobile browsers this also drags along anything
   "floating" on the page — including the WhatsApp button — making it appear
   far off to the right in blank space instead of docked to the corner of
   the screen. Fixed: those layouts now shrink properly on narrow screens,
   and the WhatsApp button (and anything else floating) stays correctly
   docked to the screen at every width.

2. New: Enquiries can now be forwarded to WhatsApp with one tap.
   Every enquiry notification email now includes a ready-made WhatsApp link
   at the bottom with the enquirer's full details pre-filled as the message
   — open the email, tap the link, and it opens WhatsApp with everything
   ready to send to your business WhatsApp number (the one set under
   Appearance > Customize > MMI Brand Settings > WhatsApp Number). The same
   "Forward via WhatsApp" button has also been added to each enquiry in the
   Staff Dashboard, next to "Email Directly". This requires no extra account,
   API, or cost — WhatsApp always requires a human tap to actually send a
   message, so there's no such thing as a fully silent auto-send, but this
   makes forwarding a one-tap action instead of manual retyping.

3. Reminder: enquiry emails still need SMTP set up.
   If enquiries aren't reaching your inbox yet, this is expected until the
   one-time SMTP setup below is completed — every enquiry is still always
   saved to Dashboard > Enquiries and the Staff Dashboard either way, so
   nothing is lost in the meantime. See "EMAIL SETUP" below and follow it
   through to clicking "Send Test Email" to confirm delivery.

-----------------------------------------------------------------------------
WHAT'S NEW IN 1.8.0
-----------------------------------------------------------------------------

1. Reliable email delivery for enquiries (SMTP).
   New: Settings > MMI Email in wp-admin. Configure a real SMTP connection
   (Gmail, your host's SMTP, or any provider) so enquiries reach your inbox
   even though this host's PHP mail() function is unreliable. Includes a
   "Send Test Email" button so you can confirm delivery works before relying
   on it. See "EMAIL SETUP" below — this needs a few minutes of setup.

2. Front-end Staff Dashboard.
   A new "Staff" login (separate from wp-admin) where staff can:
     - See every Contact form enquiry, with name/email/phone/service/message.
     - Mark each one Responded / Not Responded.
     - Reply to an enquiry by email directly from the dashboard — the reply
       is sent to the visitor's email and logged against that enquiry.
     - Moderate site comments (approve/unapprove/mark spam/trash/reply).
   See "STAFF DASHBOARD SETUP" below.

3. Homepage redesign.
   Refreshed hero section, a new "How We Work" process section, and general
   visual polish throughout. No fabricated statistics or testimonials were
   added — if you'd like real numbers or client quotes featured, send them
   over and they can be added.

4. Bug fix: the Products preview section on the homepage now sits on the
   theme's alternate (light grey) background band for better visual rhythm,
   and the "Ready to start your next project?" banner at the bottom of the
   homepage — which was previously missing its styling — now displays
   correctly with the intended blue gradient background.

No other behaviour changed from 1.7.0. The Contact form fix and Product
Description field from 1.7.0 are both still included.

-----------------------------------------------------------------------------
INSTALLATION (fresh install)
-----------------------------------------------------------------------------

1. In wp-admin, go to Appearance > Themes > Add New Theme > Upload Theme.
2. Choose mmi-technologies-ltd.zip and click Install Now, then Activate.
3. Complete the manual setup below.

INSTALLATION (updating from an earlier version)

1. Appearance > Themes > Add New Theme > Upload Theme > choose the zip.
   WordPress will offer to replace the currently-installed theme — confirm
   that.
2. IMPORTANT for this update specifically: go to Appearance > Themes and
   click "Activate" again on MMI Technologies Ltd, even though it's already
   active — this guarantees the new "Staff" role is registered immediately
   rather than waiting for WordPress's own timing. (The theme also registers
   it automatically on the next page load either way, so this is a
   belt-and-braces step, not a strict requirement.)
3. Your existing Pages, Products, Projects, menu, and logo are untouched —
   nothing needs to be redone.

-----------------------------------------------------------------------------
MANUAL SETUP (fresh install only — skip if updating)
-----------------------------------------------------------------------------

STEP 1 — Create these 8 Pages
(Pages > Add New. For each: enter the Title, publish it, then in the
"Page Attributes" panel on the right, set "Template" to the one listed.)

  Title            Template (Page Attributes > Template)
  --------         --------------------------------------
  Home             Default Template (leave as-is)
  About            About Page
  Services         Services Page
  Products         Products Page
  Projects         Projects Page
  Contact          Contact Page
  Staff Login      Staff Login
  Staff Dashboard  Staff Dashboard

  (The web address WordPress gives each page doesn't matter — the theme
  finds each page by its Template setting, not its slug.)

  Note: do NOT add "Staff Login" or "Staff Dashboard" to your public menus —
  they're meant to be reached directly by staff, not browsed by visitors.
  You can share the Staff Login page's link with your team directly.

STEP 2 — Set the Home page as your site's front page
  Settings > Reading > "Your homepage displays" > Choose "A static page" >
  set "Homepage" to the "Home" page you created > Save Changes.

STEP 3 — Build the main menu
  Appearance > Menus > create a menu named "Main Menu", add these 6 public
  pages to it in this order: Home, About, Services, Products, Projects,
  Contact. Under "Menu Settings", tick both "Primary Menu" and "Footer
  Menu" as Display locations, then Save Menu.

STEP 4 — Set your logo and brand color
  Appearance > Customize > Site Identity > Logo — upload your logo file.
  Appearance > Customize > MMI Brand Settings > Primary Brand Color — this
  defaults to the brand blue (#0B7FE0); change it if needed.
  Appearance > Customize > MMI Brand Settings > WhatsApp Number — the
  number used by the WhatsApp button (digits + country code, no spaces).

STEP 5 — Set up email delivery (see EMAIL SETUP below).

STEP 6 — Create staff accounts (see STAFF DASHBOARD SETUP below).

STEP 7 — Add your Products and Projects (see PRODUCTS & PROJECTS below).

-----------------------------------------------------------------------------
EMAIL SETUP (do this once)
-----------------------------------------------------------------------------

Go to Settings > MMI Email in wp-admin.

If sending from a Gmail / Google Workspace address (e.g.
mmitechnologies1@gmail.com):
  1. On the Google Account you'll send from, turn on 2-Step Verification
     (myaccount.google.com/security) if it isn't already on.
  2. Create an "App Password": myaccount.google.com/apppasswords > choose
     "Mail" as the app > Generate. Google gives you a 16-character code —
     copy it.
  3. Back in Settings > MMI Email:
       Enable SMTP:      checked
       SMTP Host:        smtp.gmail.com
       SMTP Port:        587
       Encryption:       TLS
       SMTP Username:    mmitechnologies1@gmail.com (the full address)
       SMTP Password:    the 16-character App Password from step 2
                          (NOT your normal Gmail password)
       "From" Email:     mmitechnologies1@gmail.com
       "From" Name:      MMI Technologies Ltd
       Send Enquiries To: mmitechnologies1@gmail.com
  4. Click "Save Settings", then scroll down and click "Send Test Email".
     Check the inbox to confirm it arrived (also check Spam the first time).

If your web host gave you a different SMTP address instead (check with
your hosting provider or web developer for these details), use their host/
port/username/password instead of the Gmail ones above.

Once this is saved and the test email arrives successfully, every new
Contact form enquiry will also be emailed to the "Send Enquiries To"
address automatically. Every enquiry is ALSO always saved to Dashboard >
Enquiries (wp-admin) and to the Staff Dashboard regardless of whether email
delivery is working, so nothing is ever lost even if an SMTP setting is
wrong.

-----------------------------------------------------------------------------
STAFF DASHBOARD SETUP
-----------------------------------------------------------------------------

Creating a staff account:
  1. wp-admin > Users > Add New.
  2. Fill in their username, email, and a password (or let WordPress
     generate one).
  3. Under "Role", choose "Staff".
  4. Click "Add New User".
  5. Share the Staff Login page's web address with them directly (it is
     NOT in the public menu) along with their username and password.

What Staff can do:
  - Log in ONLY at the Staff Login page — they cannot access wp-admin at
    all (if they try, they're redirected straight to the dashboard).
  - See every enquiry submitted through the Contact form.
  - Mark an enquiry "Responded" or "Not Responded" — useful for tracking
    what still needs a reply.
  - Reply to an enquiry by email straight from the dashboard (this uses
    the email settings configured above, and automatically marks the
    enquiry "Responded").
  - Approve, unapprove, mark as spam, trash, or reply to comments on the
    site, in the Comments tab of the same dashboard.

Administrator accounts automatically have full access to the same
dashboard too (in addition to wp-admin) — there's no need to create a
separate Staff account for yourself if you're already an Administrator.

-----------------------------------------------------------------------------
PRODUCTS & PROJECTS
-----------------------------------------------------------------------------

PRODUCTS (Dashboard > Products)
  Click "Add New" and fill in:
    - Product name         → the Title field at the top.
    - Featured Image       → the "Set featured image" box (right sidebar) —
                              this is the product's main photo.
    - Availability         → "In Stock" / "Out of Stock" (right sidebar).
    - Product Description  → shows a short summary on the Products listing
                              page and the full text on the product's own
                              page.
    - Additional Product Images → click "Add Images" to attach more photos;
                              these appear as a clickable thumbnail gallery
                              on the product's own page.
    - Category              → Products > Categories (left sidebar) lets you
                              create categories like "Solar", "CCTV &
                              Security", etc.; assign one to each product in
                              the "Product Categories" box on the right.
  Editing, deleting, and reordering are the standard WordPress admin list
  screen (Dashboard > Products > All Products).

PROJECTS (Dashboard > Projects)
  Click "Add New" and fill in:
    - Project name          → the Title field.
    - Featured Image        → main project photo.
    - Project Type          → e.g. "Street Lighting" (right sidebar).
    - Location               → e.g. "Ilorin, Kwara State" (right sidebar).
    - Additional Project Images → same gallery picker as Products.
    - Project details        → the main content editor — write the story of
                              the project here; it displays on the
                              project's own page.

If a product or project has no image yet, its card shows a neutral
placeholder icon instead of a broken image — nothing crashes if you add the
details now and the photos later.

-----------------------------------------------------------------------------
CONTACT FORM
-----------------------------------------------------------------------------

Every submission from the "Send Us an Enquiry" form on the Contact page is:
  1. Saved to Dashboard > Enquiries (wp-admin) and to the Staff Dashboard,
     always, regardless of email delivery.
  2. Emailed to the address set under Settings > MMI Email > "Send
     Enquiries To" — once SMTP is configured as described above. That email
     includes a one-tap link to forward the enquiry straight to your
     business WhatsApp number. The same "Forward via WhatsApp" button is
     also available on every enquiry in the Staff Dashboard.
The visitor sees a success message either way and is offered the WhatsApp
button as an alternative way to reach you.

-----------------------------------------------------------------------------
AFTER ANY FUTURE THEME UPDATE
-----------------------------------------------------------------------------

This site uses the SpeedyCache caching plugin. After installing any updated
version of this theme:
  1. Go to SpeedyCache's settings and clear/purge the cache.
  2. Hard-refresh your browser (Ctrl+Shift+R / Cmd+Shift+R) before judging
     whether a fix has taken effect — otherwise you may still be looking at
     a cached copy of the old CSS/JS.

-----------------------------------------------------------------------------
SUPPORT NOTES
-----------------------------------------------------------------------------

- No automatic setup runs on activation or on any page load beyond
  registering the theme's post types, taxonomy and the "Staff" user role —
  standard, lightweight WordPress behaviour that does not touch images,
  pages, or menus.
- If a page shows "Page Not Found", double-check its Page Attributes >
  Template is set correctly and that Settings > Permalinks has been saved
  at least once (Settings > Permalinks > Save Changes, without changing
  anything, refreshes the rewrite rules).
- SMTP credentials entered under Settings > MMI Email are only ever visible
  to Administrators and are stored the same way any standard WordPress
  plugin setting is stored.
