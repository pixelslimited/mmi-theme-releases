<?php
/**
 * Front page template.
 *
 * @package MMI_Technologies
 */
get_header();
?>

<section class="hero">
	<div class="hero-mesh" aria-hidden="true"></div>
	<div class="hero-blob hero-blob-1" aria-hidden="true"></div>
	<div class="hero-blob hero-blob-2" aria-hidden="true"></div>
	<div class="container hero-inner">
		<div class="hero-copy">
			<span class="hero-eyebrow"><span class="hero-dot" aria-hidden="true"></span><?php esc_html_e( 'Power · Security · Technology', 'mmi-tech' ); ?></span>
			<h1><?php echo wp_kses_post( __( 'Power, security &amp; technology that <span class="hl">keeps Nigeria running</span>', 'mmi-tech' ) ); ?></h1>
			<p><?php esc_html_e( 'MMI Technologies Ltd designs, supplies and installs solar power systems, CCTV and security, networks, IT and payment systems, and handles construction and consultancy, built to last and backed by expertise.', 'mmi-tech' ); ?></p>
			<div class="hero-actions">
				<a href="<?php echo esc_url( mmi_get_contact_page_url() ); ?>" class="btn btn-primary btn-lg"><?php esc_html_e( 'Get a Quote', 'mmi-tech' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/services/' ) ); ?>" class="btn btn-outline-light btn-lg"><?php esc_html_e( 'Our Services', 'mmi-tech' ); ?></a>
			</div>
			<ul class="hero-trust-list">
				<li><?php mmi_icon( 'check' ); ?> <?php esc_html_e( 'Certified Technicians', 'mmi-tech' ); ?></li>
				<li><?php mmi_icon( 'check' ); ?> <?php esc_html_e( 'Genuine Equipment', 'mmi-tech' ); ?></li>
				<li><?php mmi_icon( 'check' ); ?> <?php esc_html_e( 'After-Sales Support', 'mmi-tech' ); ?></li>
			</ul>
		</div>

		<div class="hero-visual" aria-hidden="true">
			<div class="hero-visual-ring"></div>
			<div class="hero-visual-ring hero-visual-ring-2"></div>
			<div class="hero-visual-card hero-visual-card-1"><span class="hero-visual-icon"><?php mmi_icon( 'solar' ); ?></span><span><?php esc_html_e( 'Solar Power', 'mmi-tech' ); ?></span></div>
			<div class="hero-visual-card hero-visual-card-2"><span class="hero-visual-icon"><?php mmi_icon( 'cctv' ); ?></span><span><?php esc_html_e( 'CCTV & Security', 'mmi-tech' ); ?></span></div>
			<div class="hero-visual-card hero-visual-card-3"><span class="hero-visual-icon"><?php mmi_icon( 'network' ); ?></span><span><?php esc_html_e( 'Networking', 'mmi-tech' ); ?></span></div>
		</div>
	</div>
</section>

<section class="ticker" aria-label="<?php esc_attr_e( 'Our services', 'mmi-tech' ); ?>">
	<div class="ticker-track" aria-hidden="true">
		<?php
		$mmi_tick = array( 'Solar Power', 'CCTV & Security', 'Networking', 'IT & Payment Systems', 'Construction', 'Import & Supply', 'Consultancy', 'Design & Printing' );
		for ( $mmi_r = 0; $mmi_r < 2; $mmi_r++ ) {
			foreach ( $mmi_tick as $mmi_t ) {
				echo '<span>' . esc_html( $mmi_t ) . '</span><i></i>';
			}
		}
		?>
	</div>
</section>

<section class="section services-preview">
	<div class="container">
		<div class="section-heading"><span class="kicker" aria-hidden="true"></span>
			<h2><?php esc_html_e( 'What we do', 'mmi-tech' ); ?></h2>
			<p><?php esc_html_e( 'A full range of technology and infrastructure services under one roof.', 'mmi-tech' ); ?></p>
		</div>
		<div class="services-grid">
			<?php
			$services = array(
				array( 'icon' => 'solar', 'title' => __( 'Solar Power Solutions', 'mmi-tech' ), 'desc' => __( 'Design, supply and installation of reliable solar power systems for homes, offices and institutions.', 'mmi-tech' ) ),
				array( 'icon' => 'cctv', 'title' => __( 'CCTV, Networking &amp; Security', 'mmi-tech' ), 'desc' => __( 'Surveillance systems, structured networking and cyber security to keep your premises and data safe.', 'mmi-tech' ) ),
				array( 'icon' => 'it', 'title' => __( 'IT &amp; Payment Systems', 'mmi-tech' ), 'desc' => __( 'IT equipment supply, support and payment/POS system integration for businesses of all sizes.', 'mmi-tech' ) ),
				array( 'icon' => 'construction', 'title' => __( 'Construction &amp; Renovation', 'mmi-tech' ), 'desc' => __( 'Construction, renovation and facility management delivered to specification and on schedule.', 'mmi-tech' ) ),
				array( 'icon' => 'supply', 'title' => __( 'Import &amp; Supply', 'mmi-tech' ), 'desc' => __( 'Sourcing, import and cargo management of technical equipment and materials.', 'mmi-tech' ) ),
				array( 'icon' => 'consultancy', 'title' => __( 'Consultancy &amp; Technical Support', 'mmi-tech' ), 'desc' => __( 'Expert consultancy and ongoing technical support across all our service areas.', 'mmi-tech' ) ),
				array( 'icon' => 'design', 'title' => __( 'Design, Printing &amp; Publishing', 'mmi-tech' ), 'desc' => __( 'Graphic design, printing and publishing services for corporate and personal needs.', 'mmi-tech' ) ),
			);
			foreach ( $services as $mmi_i => $service ) :
				?>
				<div class="service-card mmi-reveal" style="transition-delay: <?php echo esc_attr( min( $mmi_i * 60, 300 ) ); ?>ms;">
					<span class="service-icon"><?php mmi_icon( $service['icon'] ); ?></span>
					<h3><?php echo wp_kses_post( $service['title'] ); ?></h3>
					<p><?php echo wp_kses_post( $service['desc'] ); ?></p>
				</div>
				<?php
			endforeach;
			?>
		</div>
	</div>
</section>

<section class="section how-we-work alt-bg">
	<div class="container">
		<div class="section-heading"><span class="kicker" aria-hidden="true"></span>
			<h2><?php esc_html_e( 'How We Work', 'mmi-tech' ); ?></h2>
			<p><?php esc_html_e( 'A straightforward process from first conversation to ongoing support.', 'mmi-tech' ); ?></p>
		</div>
		<div class="process-steps">
			<?php
			$steps = array(
				array( 'title' => __( 'Consult', 'mmi-tech' ), 'desc' => __( 'We discuss your requirements, site conditions and budget to understand exactly what you need.', 'mmi-tech' ) ),
				array( 'title' => __( 'Design &amp; Quote', 'mmi-tech' ), 'desc' => __( 'We propose a solution sized to your needs and provide a clear, itemized quote.', 'mmi-tech' ) ),
				array( 'title' => __( 'Supply &amp; Install', 'mmi-tech' ), 'desc' => __( 'Our technicians handle sourcing, delivery and professional installation.', 'mmi-tech' ) ),
				array( 'title' => __( 'Support', 'mmi-tech' ), 'desc' => __( 'We stay reachable after installation for maintenance, troubleshooting and future upgrades.', 'mmi-tech' ) ),
			);
			foreach ( $steps as $index => $step ) :
				?>
				<div class="process-step mmi-reveal" style="transition-delay: <?php echo esc_attr( min( $index * 80, 300 ) ); ?>ms;">
					<span class="process-step-number"><?php echo esc_html( str_pad( $index + 1, 2, '0', STR_PAD_LEFT ) ); ?></span>
					<h3><?php echo wp_kses_post( $step['title'] ); ?></h3>
					<p><?php echo wp_kses_post( $step['desc'] ); ?></p>
				</div>
				<?php
			endforeach;
			?>
		</div>
	</div>
</section>

<section class="section why-choose-us">
	<div class="container">
		<div class="section-heading"><span class="kicker" aria-hidden="true"></span>
			<h2><?php esc_html_e( 'Why Choose MMI Technologies Ltd?', 'mmi-tech' ); ?></h2>
			<p><?php esc_html_e( 'We are dedicated to delivering results that exceed expectations and provide lasting value.', 'mmi-tech' ); ?></p>
		</div>
		<div class="why-choose-list">
			<?php
			$reasons = array(
				array( 'icon' => 'innovation', 'title' => __( 'Technical Innovation', 'mmi-tech' ), 'desc' => __( 'Innovation is at the heart of MMI Technologies. Our team continuously explores advanced technologies to offer the latest and most efficient solutions, ensuring our clients benefit from cutting-edge advancements.', 'mmi-tech' ) ),
				array( 'icon' => 'eco', 'title' => __( 'Environmental Sustainability', 'mmi-tech' ), 'desc' => __( 'We are committed to sustainable practices that reduce environmental impact. MMI Technologies integrates eco-friendly solutions in our processes and products, aligning with global efforts to protect our planet.', 'mmi-tech' ) ),
				array( 'icon' => 'diversify', 'title' => __( 'Product Diversification', 'mmi-tech' ), 'desc' => __( 'Our broad portfolio of products and services enables us to meet the diverse needs of clients across industries. This diversity enhances our ability to deliver customized solutions that best fit our customers\' goals.', 'mmi-tech' ) ),
				array( 'icon' => 'network', 'title' => __( 'Partnerships and Distribution Network', 'mmi-tech' ), 'desc' => __( 'Strong partnerships and a reliable distribution network are key to our success. We work with trusted partners to ensure the highest quality and timely delivery, expanding our reach and impact across regions.', 'mmi-tech' ) ),
			);
			foreach ( $reasons as $mmi_i => $reason ) :
				?>
				<div class="why-choose-item mmi-reveal" style="transition-delay: <?php echo esc_attr( min( $mmi_i * 70, 300 ) ); ?>ms;">
					<span class="why-choose-icon"><?php mmi_icon( $reason['icon'] ); ?></span>
					<div class="why-choose-copy">
						<h3><?php echo esc_html( $reason['title'] ); ?></h3>
						<p><?php echo esc_html( $reason['desc'] ); ?></p>
					</div>
				</div>
				<?php
			endforeach;
			?>
		</div>
	</div>
</section>

<section class="section products-preview alt-bg">
	<div class="container">
		<div class="section-heading"><span class="kicker" aria-hidden="true"></span>
			<h2><?php esc_html_e( 'Our Products', 'mmi-tech' ); ?></h2>
			<p><?php esc_html_e( 'A selection of the equipment and systems we supply and install.', 'mmi-tech' ); ?></p>
		</div>
		<?php mmi_render_products( array( 'posts_per_page' => 6 ) ); ?>
		<div class="section-cta">
			<a href="<?php echo esc_url( mmi_get_products_page_url() ); ?>" class="btn btn-outline"><?php esc_html_e( 'View All Products', 'mmi-tech' ); ?></a>
		</div>
	</div>
</section>

<section class="section projects-preview">
	<div class="container">
		<div class="section-heading"><span class="kicker" aria-hidden="true"></span>
			<h2><?php esc_html_e( 'Recent Projects', 'mmi-tech' ); ?></h2>
			<p><?php esc_html_e( 'A look at some of the work we\'ve delivered for our clients.', 'mmi-tech' ); ?></p>
		</div>
		<?php mmi_render_projects( array( 'posts_per_page' => 3 ) ); ?>
		<div class="section-cta">
			<a href="<?php echo esc_url( mmi_get_projects_page_url() ); ?>" class="btn btn-outline"><?php esc_html_e( 'View All Projects', 'mmi-tech' ); ?></a>
		</div>
	</div>
</section>

<section class="cta-banner">
	<div class="hero-mesh" aria-hidden="true"></div>
	<div class="container cta-banner-inner">
		<h2><?php esc_html_e( 'Ready to start your next project?', 'mmi-tech' ); ?></h2>
		<p><?php esc_html_e( 'Talk to our team today and let\'s find the right solution for you.', 'mmi-tech' ); ?></p>
		<a href="<?php echo esc_url( mmi_get_contact_page_url() ); ?>" class="btn btn-light btn-lg"><?php esc_html_e( 'Get a Quote', 'mmi-tech' ); ?></a>
	</div>
</section>

<?php get_footer(); ?>
