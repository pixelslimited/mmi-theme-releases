<?php
/**
 * Template Name: Services Page
 *
 * @package MMI_Technologies
 */
get_header();

$services = array(
	array(
		'icon'  => 'solar',
		'title' => __( 'Solar Power Solutions', 'mmi-tech' ),
		'desc'  => __( 'End-to-end solar power systems — design, equipment supply and installation — for homes, offices, institutions and off-grid sites, sized to your actual power needs.', 'mmi-tech' ),
	),
	array(
		'icon'  => 'cctv',
		'title' => __( 'CCTV, Networking &amp; Cyber Security', 'mmi-tech' ),
		'desc'  => __( 'Surveillance camera systems, structured network cabling, and cyber security measures to protect your premises, staff and data.', 'mmi-tech' ),
	),
	array(
		'icon'  => 'it',
		'title' => __( 'IT &amp; Payment Systems', 'mmi-tech' ),
		'desc'  => __( 'Supply and support of IT equipment, plus integration of point-of-sale and payment systems for retail and enterprise use.', 'mmi-tech' ),
	),
	array(
		'icon'  => 'construction',
		'title' => __( 'Construction &amp; Renovation', 'mmi-tech' ),
		'desc'  => __( 'Construction, renovation and facility management services delivered to specification, on time and within budget.', 'mmi-tech' ),
	),
	array(
		'icon'  => 'supply',
		'title' => __( 'Import &amp; Supply', 'mmi-tech' ),
		'desc'  => __( 'Sourcing, importation and cargo management of technical equipment and materials from trusted international partners.', 'mmi-tech' ),
	),
	array(
		'icon'  => 'consultancy',
		'title' => __( 'Consultancy &amp; Technical Support', 'mmi-tech' ),
		'desc'  => __( 'Expert consultancy and ongoing technical support to help you plan, implement and maintain the right solution.', 'mmi-tech' ),
	),
	array(
		'icon'  => 'design',
		'title' => __( 'Design, Printing &amp; Publishing', 'mmi-tech' ),
		'desc'  => __( 'Graphic design, printing and publishing services for corporate branding, marketing materials and publications.', 'mmi-tech' ),
	),
);
?>

<section class="page-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<?php mmi_breadcrumbs(); ?>
	</div>
</section>

<main class="mmi-services">
	<div class="container">
		<?php
		while ( have_posts() ) :
			the_post();
			if ( get_the_content() ) :
				?>
				<div class="mmi-post-content"><?php the_content(); ?></div>
				<?php
			endif;
		endwhile;
		?>

		<div class="services-grid services-grid-full">
			<?php foreach ( $services as $service ) : ?>
				<div class="service-card">
					<span class="service-icon"><?php mmi_icon( $service['icon'] ); ?></span>
					<h3><?php echo wp_kses_post( $service['title'] ); ?></h3>
					<p><?php echo wp_kses_post( $service['desc'] ); ?></p>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="section-cta">
			<a href="<?php echo esc_url( mmi_get_contact_page_url() ); ?>" class="btn btn-primary btn-lg"><?php esc_html_e( 'Discuss Your Requirements', 'mmi-tech' ); ?></a>
		</div>
	</div>
</main>

<?php get_footer(); ?>
