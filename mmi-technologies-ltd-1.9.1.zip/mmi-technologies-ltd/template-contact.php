<?php
/**
 * Template Name: Contact Page
 *
 * IMPORTANT — see the note at the top of inc/forms-handler.php: the name
 * field below MUST stay named "mmi_name", not "name". Renaming it back to
 * "name" reintroduces a 404-on-submit bug caused by a collision with
 * WordPress's own built-in "name" query var.
 *
 * @package MMI_Technologies
 */
get_header();
?>

<section class="page-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<p><?php esc_html_e( 'We\'d love to hear about your project &mdash; reach out any time.', 'mmi-tech' ); ?></p>
		<?php mmi_breadcrumbs(); ?>
	</div>
</section>

<main class="mmi-contact">
	<div class="container contact-grid">
		<div class="contact-info">
			<?php
			while ( have_posts() ) :
				the_post();
				if ( get_the_content() ) :
					?>
					<div class="mmi-post-content"><?php the_content(); ?></div>
					<?php
				endif;
			endwhile;
			?>

			<ul class="contact-info-list">
				<li>
					<span class="contact-info-icon"><?php mmi_icon( 'phone' ); ?></span>
					<div>
						<strong><?php esc_html_e( 'Phone', 'mmi-tech' ); ?></strong>
						<a href="tel:+2347019448554">+234 701 944 8554</a><br>
						<a href="tel:+2347076111066">+234 707 611 1066</a><br>
						<a href="tel:+2347071751117">+234 707 175 1117</a>
					</div>
				</li>
				<li>
					<span class="contact-info-icon"><?php mmi_icon( 'mail' ); ?></span>
					<div>
						<strong><?php esc_html_e( 'Email', 'mmi-tech' ); ?></strong>
						<a href="mailto:mmitechnologies1@gmail.com">mmitechnologies1@gmail.com</a>
					</div>
				</li>
				<li>
					<span class="contact-info-icon"><?php mmi_icon( 'clock' ); ?></span>
					<div>
						<strong><?php esc_html_e( 'Working Hours', 'mmi-tech' ); ?></strong>
						<?php esc_html_e( 'Mon &ndash; Sat: 9:00 AM &ndash; 5:30 PM', 'mmi-tech' ); ?>
					</div>
				</li>
			</ul>

			<a href="<?php echo esc_url( mmi_whatsapp_url() ); ?>" class="btn btn-primary btn-lg" target="_blank" rel="noopener"><?php mmi_icon( 'phone' ); ?> <?php esc_html_e( 'Chat on WhatsApp', 'mmi-tech' ); ?></a>
		</div>

		<div class="contact-form-panel">
			<h2><?php esc_html_e( 'Send Us an Enquiry', 'mmi-tech' ); ?></h2>
			<p><?php esc_html_e( 'Fill in the form and we will respond as soon as possible.', 'mmi-tech' ); ?></p>

			<?php mmi_form_notice(); ?>

			<form method="post" action="<?php echo esc_url( get_permalink() ); ?>" class="mmi-form" novalidate>
				<input type="hidden" name="mmi_form" value="contact">
				<?php wp_nonce_field( 'mmi_contact_submit', 'mmi_contact_nonce' ); ?>

				<p class="mmi-honeypot-field">
					<label for="mmi_website"><?php esc_html_e( 'Website', 'mmi-tech' ); ?></label>
					<input type="text" name="mmi_website" id="mmi_website" tabindex="-1" autocomplete="off">
				</p>

				<div class="form-row">
					<div class="form-field">
						<label for="mmi_name"><?php esc_html_e( 'Name', 'mmi-tech' ); ?> *</label>
						<input type="text" name="mmi_name" id="mmi_name" required>
					</div>
					<div class="form-field">
						<label for="phone"><?php esc_html_e( 'Phone', 'mmi-tech' ); ?></label>
						<input type="tel" name="phone" id="phone">
					</div>
				</div>

				<div class="form-row">
					<div class="form-field">
						<label for="email"><?php esc_html_e( 'Email', 'mmi-tech' ); ?> *</label>
						<input type="email" name="email" id="email" required>
					</div>
					<div class="form-field">
						<label for="service"><?php esc_html_e( 'Service Required', 'mmi-tech' ); ?></label>
						<select name="service" id="service">
							<option><?php esc_html_e( 'Solar Power', 'mmi-tech' ); ?></option>
							<option><?php esc_html_e( 'CCTV, Networking &amp; Security', 'mmi-tech' ); ?></option>
							<option><?php esc_html_e( 'IT &amp; Payment Systems', 'mmi-tech' ); ?></option>
							<option><?php esc_html_e( 'Construction &amp; Renovation', 'mmi-tech' ); ?></option>
							<option><?php esc_html_e( 'Import &amp; Supply', 'mmi-tech' ); ?></option>
							<option><?php esc_html_e( 'Consultancy &amp; Technical Support', 'mmi-tech' ); ?></option>
							<option><?php esc_html_e( 'Design, Printing &amp; Publishing', 'mmi-tech' ); ?></option>
							<option><?php esc_html_e( 'Other', 'mmi-tech' ); ?></option>
						</select>
					</div>
				</div>

				<div class="form-field">
					<label for="message"><?php esc_html_e( 'Message', 'mmi-tech' ); ?> *</label>
					<textarea name="message" id="message" rows="5" required></textarea>
				</div>

				<button type="submit" class="btn btn-primary btn-lg"><?php esc_html_e( 'Send Enquiry', 'mmi-tech' ); ?></button>
			</form>
		</div>
	</div>
</main>

<?php get_footer(); ?>
