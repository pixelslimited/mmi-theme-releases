<?php
/**
 * Fallback template (blog index / catch-all).
 *
 * @package MMI_Technologies
 */
get_header();
?>
<main class="mmi-generic-page">
	<div class="container">
		<?php if ( have_posts() ) : ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<article <?php post_class( 'mmi-post' ); ?>>
					<h1><?php the_title(); ?></h1>
					<div class="mmi-post-content"><?php the_content(); ?></div>
				</article>
			<?php endwhile; ?>
			<?php the_posts_pagination(); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'Nothing found.', 'mmi-tech' ); ?></p>
		<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
