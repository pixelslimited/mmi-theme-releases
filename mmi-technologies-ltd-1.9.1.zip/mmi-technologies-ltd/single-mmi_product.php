<?php
/**
 * Single Product template.
 *
 * @package MMI_Technologies
 */
get_header();

while ( have_posts() ) :
	the_post();

	$post_id     = get_the_ID();
	$status      = mmi_get_product_status( $post_id );
	$status_label= mmi_get_product_status_label( $post_id );
	$terms       = get_the_terms( $post_id, 'mmi_product_category' );
	$category    = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
	$description = mmi_get_product_description( $post_id );

	// Combined, ordered gallery: featured image first, then the gallery picker images.
	$image_ids = array();
	if ( has_post_thumbnail() ) {
		$image_ids[] = get_post_thumbnail_id();
	}
	$image_ids = array_merge( $image_ids, mmi_get_gallery_ids( $post_id, '_mmi_product_gallery' ) );
	$image_ids = array_unique( $image_ids );
	?>

	<section class="page-hero page-hero-sm">
		<div class="container">
			<?php mmi_breadcrumbs(); ?>
		</div>
	</section>

	<main class="mmi-single-item">
		<div class="container item-detail-grid">

			<div class="mmi-item-gallery">
				<?php if ( ! empty( $image_ids ) ) : ?>
					<?php
					$first     = array_shift( $image_ids );
					$first_src = wp_get_attachment_image_src( $first, 'large' );
					?>
					<div class="mmi-gallery-main">
						<img src="<?php echo esc_url( $first_src[0] ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>">
					</div>
					<?php if ( ! empty( $image_ids ) ) : ?>
						<div class="mmi-gallery-thumbs">
							<button type="button" class="mmi-gallery-thumb is-active" data-full="<?php echo esc_url( $first_src[0] ); ?>" data-alt="<?php echo esc_attr( get_the_title() ); ?>">
								<img src="<?php echo esc_url( wp_get_attachment_image_url( $first, 'mmi-gallery-thumb' ) ); ?>" alt="">
							</button>
							<?php foreach ( $image_ids as $img_id ) : ?>
								<?php $full = wp_get_attachment_image_src( $img_id, 'large' ); ?>
								<button type="button" class="mmi-gallery-thumb" data-full="<?php echo esc_url( $full[0] ); ?>" data-alt="<?php echo esc_attr( get_the_title() ); ?>">
									<img src="<?php echo esc_url( wp_get_attachment_image_url( $img_id, 'mmi-gallery-thumb' ) ); ?>" alt="">
								</button>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				<?php else : ?>
					<div class="mmi-gallery-main">
						<span class="media-placeholder media-placeholder-lg"><?php mmi_icon( 'it' ); ?></span>
					</div>
				<?php endif; ?>
			</div>

			<div class="mmi-item-info">
				<?php if ( $category ) : ?>
					<span class="mmi-card-eyebrow"><?php echo esc_html( $category ); ?></span>
				<?php endif; ?>
				<h1><?php the_title(); ?></h1>
				<span class="stock-badge stock-badge-inline stock-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $status_label ); ?></span>

				<?php if ( $description ) : ?>
					<div class="mmi-item-description"><?php echo wp_kses_post( wpautop( $description ) ); ?></div>
				<?php endif; ?>

				<?php if ( get_the_content() ) : ?>
					<div class="mmi-post-content"><?php the_content(); ?></div>
				<?php endif; ?>

				<div class="mmi-item-cta">
					<a href="<?php echo esc_url( mmi_whatsapp_url( sprintf( __( 'Hello, I would like to request the price of %s.', 'mmi-tech' ), get_the_title() ) ) ); ?>" class="btn btn-primary btn-lg" target="_blank" rel="noopener"><?php esc_html_e( 'Request Price via WhatsApp', 'mmi-tech' ); ?></a>
					<a href="<?php echo esc_url( mmi_get_contact_page_url() ); ?>" class="btn btn-outline btn-lg"><?php esc_html_e( 'Get a Quote', 'mmi-tech' ); ?></a>
				</div>
			</div>
		</div>

		<div class="container">
			<a href="<?php echo esc_url( mmi_get_products_page_url() ); ?>" class="mmi-back-link"><?php mmi_icon( 'arrow' ); ?> <?php esc_html_e( 'Back to All Products', 'mmi-tech' ); ?></a>
		</div>
	</main>

	<?php
endwhile;

get_footer();
