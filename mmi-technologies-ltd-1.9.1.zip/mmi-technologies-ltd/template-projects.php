<?php
/**
 * Template Name: Projects Page
 *
 * @package MMI_Technologies
 */
get_header();
?>

<section class="page-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<?php mmi_breadcrumbs(); ?>
	</div>
</section>

<main class="mmi-projects-page">
	<div class="container">
		<?php
		while ( have_posts() ) :
			the_post();
			if ( get_the_content() ) :
				?>
				<div class="mmi-post-content"><?php the_content(); ?></div>
				<?php
			endif;
		endwhile;
		?>

		<?php mmi_render_projects(); ?>
	</div>
</main>

<?php get_footer(); ?>
