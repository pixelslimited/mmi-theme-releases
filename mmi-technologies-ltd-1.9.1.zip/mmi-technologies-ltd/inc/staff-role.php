<?php
/**
 * "Staff" role: a front-end-only account for handling enquiries and
 * comments through the custom dashboard, with no access to wp-admin.
 *
 * Administrators still create these accounts the normal way — Users > Add
 * New in wp-admin — they just pick "Staff" as the role instead of
 * "Editor"/"Author"/etc. Nothing about user creation itself is custom.
 *
 * @package MMI_Technologies
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MMI_STAFF_ROLE', 'mmi_staff' );
define( 'MMI_STAFF_CAP', 'mmi_manage_enquiries' );

/**
 * Register the role. Safe to call on every request — add_role() and
 * add_cap() simply do nothing if already present, so there's no real cost
 * to also checking on 'init' rather than only on activation.
 *
 * This deliberately does NOT rely on 'after_switch_theme' alone: uploading
 * an updated theme zip over an already-active theme of the same slug (the
 * normal way this theme gets updated) does not reliably fire that hook, so
 * a brand-new role like this one could otherwise silently fail to appear
 * after an update unless the site owner happens to deactivate/reactivate.
 * Hooking to 'init' guarantees it exists as soon as this version's
 * functions.php has loaded once, with no extra step required.
 */
function mmi_register_staff_role() {
	add_role( MMI_STAFF_ROLE, __( 'Staff', 'mmi-tech' ), array(
		'read'              => true,
		MMI_STAFF_CAP       => true,
		'moderate_comments' => true,
		'edit_posts'        => false,
		'upload_files'      => false,
	) );

	$admin_role = get_role( 'administrator' );
	if ( $admin_role && ! $admin_role->has_cap( MMI_STAFF_CAP ) ) {
		$admin_role->add_cap( MMI_STAFF_CAP );
	}
}
add_action( 'after_switch_theme', 'mmi_register_staff_role' );
add_action( 'init', 'mmi_register_staff_role' );

/**
 * Whether the current user may use the staff dashboard (Staff role or any
 * Administrator).
 */
function mmi_current_user_is_staff() {
	return is_user_logged_in() && current_user_can( MMI_STAFF_CAP );
}

/**
 * Keep Staff accounts out of wp-admin entirely — send them to the front-end
 * dashboard instead. Administrators are never affected by this.
 */
function mmi_redirect_staff_from_wp_admin() {
	if ( ! is_admin() || wp_doing_ajax() ) {
		return;
	}
	$user = wp_get_current_user();
	if ( ! $user || ! in_array( MMI_STAFF_ROLE, (array) $user->roles, true ) ) {
		return;
	}
	wp_safe_redirect( mmi_get_staff_dashboard_url() );
	exit;
}
add_action( 'admin_init', 'mmi_redirect_staff_from_wp_admin' );

/**
 * Send Staff straight to the dashboard after logging in via wp-login.php
 * too (in case someone bookmarks that page instead of the custom one).
 */
add_filter( 'login_redirect', function ( $redirect_to, $requested_redirect_to, $user ) {
	if ( $user instanceof WP_User && in_array( MMI_STAFF_ROLE, (array) $user->roles, true ) ) {
		return mmi_get_staff_dashboard_url();
	}
	return $redirect_to;
}, 10, 3 );

/**
 * Hide the wp-admin toolbar for Staff when they're viewing the front end —
 * they have no wp-admin to jump to, so the bar would just be confusing.
 */
add_action( 'after_setup_theme', function () {
	$user = wp_get_current_user();
	if ( $user && in_array( MMI_STAFF_ROLE, (array) $user->roles, true ) ) {
		show_admin_bar( false );
	}
} );

/**
 * URL helpers for the two staff-facing pages. Falls back to home if the
 * pages haven't been created yet (see mmi_get_page_url_by_template()).
 */
function mmi_get_staff_login_url() {
	return mmi_get_page_url_by_template( 'template-staff-login.php' );
}

function mmi_get_staff_dashboard_url() {
	return mmi_get_page_url_by_template( 'template-staff-dashboard.php' );
}
