<?php
/**
 * THEME UPDATER (Appearance > Theme updates)
 * New versions are published automatically from the project's repository as a signed zip.
 * The site only installs a release whose version and fingerprint carry a valid signature, so a
 * tampered or fake update is ignored. The current version is saved first and can be restored.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'MMI_UPDATE_FEED', 'https://raw.githubusercontent.com/pixelslimited/mmi-theme-releases/main/mmi-update.json' );
define( 'MMI_UPDATE_PUBKEY', 'w3M7jPpywFR+Jdv0oqDTowxV93Su66pdveOvwzVnxVU=' );

function mmi_backup_dir() {
	$up  = wp_upload_dir( null, false );
	$dir = trailingslashit( $up['basedir'] ) . 'mmi-backups';
	if ( ! is_dir( $dir ) ) { wp_mkdir_p( $dir ); }
	if ( is_dir( $dir ) && ! file_exists( $dir . '/.htaccess' ) ) {
		@file_put_contents( $dir . '/.htaccess', "Require all denied\n" ); // phpcs:ignore
		@file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore
	}
	return $dir;
}

function mmi_backups() {
	$out = array();
	foreach ( (array) glob( mmi_backup_dir() . '/mmi-*.zip' ) as $f ) {
		if ( preg_match( '/mmi-([0-9.]+)-(\d+)\.zip$/', $f, $m ) ) {
			$out[] = array( 'file' => basename( $f ), 'version' => $m[1], 'time' => (int) $m[2] );
		}
	}
	usort( $out, function ( $a, $b ) { return $b['time'] - $a['time']; } );
	return $out;
}

/** Zip the theme as it is now. Returns the path or WP_Error. */
function mmi_theme_backup() {
	if ( ! class_exists( 'ZipArchive' ) ) { return new WP_Error( 'zip', 'This server cannot make zip files, so no backup was saved.' ); }
	$dest = mmi_backup_dir() . '/mmi-' . MMI_THEME_VERSION . '-' . time() . '.zip';
	$zip  = new ZipArchive();
	if ( true !== $zip->open( $dest, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) { return new WP_Error( 'zip', 'The backup file could not be created.' ); }
	$base = wp_normalize_path( MMI_THEME_DIR );
	$it   = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( MMI_THEME_DIR, FilesystemIterator::SKIP_DOTS ) );
	foreach ( $it as $f ) {
		if ( ! $f->isFile() ) { continue; }
		$rel = ltrim( str_replace( $base, '', wp_normalize_path( $f->getPathname() ) ), '/' );
		$zip->addFile( $f->getPathname(), get_template() . '/' . $rel );
	}
	$zip->close();
	foreach ( array_slice( mmi_backups(), 3 ) as $old ) { @unlink( mmi_backup_dir() . '/' . $old['file'] ); } // phpcs:ignore
	return $dest;
}

/** Make sure a zip is really this theme. Returns its version or WP_Error. */
function mmi_check_package( $file ) {
	if ( ! class_exists( 'ZipArchive' ) ) { return '0'; }
	$zip = new ZipArchive();
	if ( true !== $zip->open( $file ) ) { return new WP_Error( 'zip', 'That file is not a valid .zip file.' ); }
	$slug  = get_template();
	$style = $zip->getFromName( $slug . '/style.css' );
	$funcs = $zip->locateName( $slug . '/functions.php' );
	$zip->close();
	if ( false === $style || false === $funcs || ! preg_match( '/Theme Name:\s*MMI Technologies/i', $style ) ) {
		return new WP_Error( 'zip', 'That zip is not the MMI Technologies theme.' );
	}
	return preg_match( '/Version:\s*([0-9.]+)/i', $style, $m ) ? $m[1] : '0';
}

function mmi_install_package( $file ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-admin/includes/theme.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	if ( 'direct' !== get_filesystem_method() ) {
		return new WP_Error( 'fs', 'This server needs FTP details to install themes. Use Appearance > Themes > Add New > Upload Theme instead.' );
	}
	WP_Filesystem();
	$skin     = new Automatic_Upgrader_Skin();
	$upgrader = new Theme_Upgrader( $skin );
	$result   = $upgrader->install( $file, array( 'overwrite_package' => true, 'clear_update_cache' => true ) );
	if ( is_wp_error( $result ) ) { return $result; }
	if ( ! $result ) {
		$msgs = array_filter( array_map( 'wp_strip_all_tags', (array) $skin->get_upgrade_messages() ) );
		return new WP_Error( 'install', 'The theme could not be installed. ' . implode( ' ', array_slice( $msgs, -2 ) ) );
	}
	delete_site_transient( 'update_themes' );
	return true;
}

/* ---------------------------------------------------------------- release feed */

function mmi_same_host( $a, $b ) {
	$ha = strtolower( (string) wp_parse_url( $a, PHP_URL_HOST ) );
	return $ha && $ha === strtolower( (string) wp_parse_url( $b, PHP_URL_HOST ) );
}

function mmi_release_signed( $version, $sha256, $sig ) {
	$sig = base64_decode( $sig, true );
	$key = base64_decode( MMI_UPDATE_PUBKEY, true );
	if ( ! $sig || 64 !== strlen( $sig ) || ! $key || ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) { return false; }
	try {
		return sodium_crypto_sign_verify_detached( $sig, 'mmi-release|' . $version . '|' . $sha256, $key );
	} catch ( \Throwable $e ) {
		return false;
	}
}

/** Latest signed release, cached for 6 hours. Returns array or null; failure reason kept in transient 'mmi_release_error'. */
function mmi_remote_release( $force = false ) {
	$cached = get_transient( 'mmi_release' );
	if ( ! $force && is_array( $cached ) ) { return $cached ? $cached : null; }
	$fail = function ( $why ) {
		set_transient( 'mmi_release', array(), HOUR_IN_SECONDS );
		set_transient( 'mmi_release_error', $why, HOUR_IN_SECONDS );
		return null;
	};
	$res = wp_safe_remote_get( add_query_arg( 'nocache', time(), MMI_UPDATE_FEED ), array( 'timeout' => 15, 'headers' => array( 'Cache-Control' => 'no-cache' ) ) );
	if ( is_wp_error( $res ) ) { return $fail( 'The update server could not be reached (' . $res->get_error_message() . ').' ); }
	if ( 200 !== (int) wp_remote_retrieve_response_code( $res ) ) { return $fail( 'The update file was not found (error ' . (int) wp_remote_retrieve_response_code( $res ) . ').' ); }
	$d = json_decode( wp_remote_retrieve_body( $res ), true );
	if ( ! is_array( $d ) || empty( $d['version'] ) || empty( $d['package'] ) ) { return $fail( 'The update file is not in the right format.' ); }
	if ( ! preg_match( '/^\d+(\.\d+){1,3}$/', (string) $d['version'] ) ) { return $fail( 'The update file has an invalid version number.' ); }
	if ( 0 !== strpos( $d['package'], 'https://' ) || ! mmi_same_host( $d['package'], MMI_UPDATE_FEED ) ) { return $fail( 'The update points to another website, so it was ignored.' ); }
	if ( empty( $d['sha256'] ) || ! preg_match( '/^[a-f0-9]{64}$/i', $d['sha256'] ) ) { return $fail( 'The update file has no valid fingerprint, so it was ignored.' ); }
	if ( ! mmi_release_signed( (string) $d['version'], strtolower( $d['sha256'] ), (string) ( $d['sig'] ?? '' ) ) ) { return $fail( 'The update is not signed by the developer, so it was ignored.' ); }
	$rel = array(
		'version' => $d['version'],
		'package' => esc_url_raw( $d['package'] ),
		'sha256'  => strtolower( $d['sha256'] ),
		'sig'     => (string) $d['sig'],
		'notes'   => isset( $d['notes'] ) ? sanitize_textarea_field( $d['notes'] ) : '',
		'date'    => isset( $d['released'] ) ? sanitize_text_field( $d['released'] ) : '',
	);
	set_transient( 'mmi_release', $rel, 6 * HOUR_IN_SECONDS );
	delete_transient( 'mmi_release_error' );
	return $rel;
}

function mmi_update_available( $force = false ) {
	$rel = mmi_remote_release( $force );
	return ( $rel && version_compare( $rel['version'], MMI_THEME_VERSION, '>' ) ) ? $rel : null;
}

function mmi_download_release( $rel ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$tmp = download_url( $rel['package'], 300 );
	if ( is_wp_error( $tmp ) ) { return new WP_Error( 'download', 'The update could not be downloaded: ' . $tmp->get_error_message() ); }
	if ( ! hash_equals( $rel['sha256'], (string) hash_file( 'sha256', $tmp ) ) || ! mmi_release_signed( $rel['version'], $rel['sha256'], $rel['sig'] ) ) {
		@unlink( $tmp ); // phpcs:ignore
		return new WP_Error( 'hash', 'The downloaded file does not match the published fingerprint, so it was not installed.' );
	}
	$ver = mmi_check_package( $tmp );
	if ( is_wp_error( $ver ) ) { @unlink( $tmp ); return $ver; } // phpcs:ignore
	if ( '0' !== $ver && $ver !== $rel['version'] ) {
		@unlink( $tmp ); // phpcs:ignore
		return new WP_Error( 'ver', 'The downloaded theme is version ' . $ver . ', not ' . $rel['version'] . ' as announced, so it was not installed.' );
	}
	return $tmp;
}

function mmi_install_release() {
	$rel = mmi_update_available( true );
	if ( ! $rel ) { return new WP_Error( 'none', 'There is no newer version to install.' ); }
	$tmp = mmi_download_release( $rel );
	if ( is_wp_error( $tmp ) ) { return $tmp; }
	$saved = mmi_theme_backup();
	$res   = mmi_install_package( $tmp );
	@unlink( $tmp ); // phpcs:ignore
	if ( is_wp_error( $res ) ) { return $res; }
	delete_transient( 'mmi_release' );
	return array( 'version' => $rel['version'], 'backup' => ! is_wp_error( $saved ) );
}

/* WordPress's own "Update now" gets the verified download and a backup. */
add_filter( 'upgrader_pre_download', function ( $reply, $package ) {
	if ( false !== $reply ) { return $reply; }
	$rel = mmi_remote_release();
	if ( ! $rel || $package !== $rel['package'] ) { return $reply; }
	if ( ! version_compare( $rel['version'], MMI_THEME_VERSION, '>' ) ) { return new WP_Error( 'old', 'That is not a newer version.' ); }
	$tmp = mmi_download_release( $rel );
	if ( is_wp_error( $tmp ) ) { return $tmp; }
	mmi_theme_backup();
	return $tmp;
}, 10, 2 );

/* Show new versions in WordPress's own update screens. */
add_filter( 'pre_set_site_transient_update_themes', function ( $transient ) {
	$rel = mmi_remote_release();
	if ( ! $rel || ! is_object( $transient ) ) { return $transient; }
	$slug = get_template();
	if ( version_compare( $rel['version'], MMI_THEME_VERSION, '>' ) ) {
		$transient->response[ $slug ] = array( 'theme' => $slug, 'new_version' => $rel['version'], 'url' => admin_url( 'themes.php?page=mmi-updates' ), 'package' => $rel['package'] );
	} elseif ( isset( $transient->response[ $slug ] ) ) {
		unset( $transient->response[ $slug ] );
	}
	return $transient;
} );

/* Never let the wordpress.org directory "update" this theme with an unrelated theme of the same name. */
add_filter( 'http_request_args', function ( $args, $url ) {
	if ( false === strpos( $url, 'api.wordpress.org/themes/update-check' ) || empty( $args['body']['themes'] ) ) { return $args; }
	$themes = json_decode( $args['body']['themes'], true );
	if ( is_array( $themes ) ) {
		unset( $themes['themes'][ get_template() ] );
		$args['body']['themes'] = wp_json_encode( $themes );
	}
	return $args;
}, 10, 2 );

/* ---------------------------------------------------------------- admin page */

add_action( 'admin_menu', function () {
	add_theme_page( 'Theme updates', 'Theme updates', 'update_themes', 'mmi-updates', 'mmi_updates_page' );
} );

function mmi_updates_page() {
	if ( ! current_user_can( 'update_themes' ) ) { wp_die( 'Not allowed.' ); }
	$msg = '';
	$err = '';
	if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['mmi_action'] ) ) {
		check_admin_referer( 'mmi_updates' );
		$act = sanitize_key( wp_unslash( $_POST['mmi_action'] ) );
		if ( 'check' === $act ) {
			mmi_remote_release( true );
			$msg = mmi_update_available() ? 'A new version is available.' : 'You are on the latest version.';
		} elseif ( 'install' === $act ) {
			$r = mmi_install_release();
			if ( is_wp_error( $r ) ) { $err = $r->get_error_message(); } else { $msg = 'Updated to version ' . $r['version'] . '.'; }
		} elseif ( 'restore' === $act ) {
			$file = basename( (string) wp_unslash( $_POST['file'] ?? '' ) );
			$path = mmi_backup_dir() . '/' . $file;
			if ( ! preg_match( '/^mmi-[0-9.]+-\d+\.zip$/', $file ) || ! is_file( $path ) ) {
				$err = 'That saved version was not found.';
			} else {
				$tmp = wp_tempnam( $file );
				copy( $path, $tmp );
				$r = mmi_install_package( $tmp );
				@unlink( $tmp ); // phpcs:ignore
				if ( is_wp_error( $r ) ) { $err = $r->get_error_message(); } else { $msg = 'Restored the saved version.'; }
			}
		}
	}
	$rel   = mmi_update_available();
	$why   = get_transient( 'mmi_release_error' );
	echo '<div class="wrap"><h1>Theme updates</h1>';
	if ( $msg ) { echo '<div class="notice notice-success"><p>' . esc_html( $msg ) . '</p></div>'; }
	if ( $err ) { echo '<div class="notice notice-error"><p>' . esc_html( $err ) . '</p></div>'; }
	echo '<p>Installed version: <strong>' . esc_html( MMI_THEME_VERSION ) . '</strong></p>';
	if ( $rel ) {
		echo '<p>New version available: <strong>' . esc_html( $rel['version'] ) . '</strong>' . ( $rel['date'] ? ' (' . esc_html( $rel['date'] ) . ')' : '' ) . '</p>';
		if ( $rel['notes'] ) { echo '<p>' . nl2br( esc_html( $rel['notes'] ) ) . '</p>'; }
	} elseif ( $why ) {
		echo '<p>' . esc_html( $why ) . '</p>';
	}
	echo '<form method="post" style="display:inline">';
	wp_nonce_field( 'mmi_updates' );
	echo '<button class="button" name="mmi_action" value="check">Check now</button> ';
	if ( $rel ) { echo '<button class="button button-primary" name="mmi_action" value="install">Update now</button>'; }
	echo '</form>';
	$b = mmi_backups();
	if ( $b ) {
		echo '<h2>Saved versions</h2><p>A copy is saved before every update. Restore one if something looks wrong.</p><ul>';
		foreach ( $b as $x ) {
			echo '<li>Version ' . esc_html( $x['version'] ) . ', saved ' . esc_html( wp_date( 'j M Y, H:i', $x['time'] ) ) . ' ';
			echo '<form method="post" style="display:inline">';
			wp_nonce_field( 'mmi_updates' );
			echo '<input type="hidden" name="file" value="' . esc_attr( $x['file'] ) . '">';
			echo '<button class="button" name="mmi_action" value="restore" onclick="return confirm(\'Restore this version?\')">Restore</button></form></li>';
		}
		echo '</ul>';
	}
	echo '</div>';
}
