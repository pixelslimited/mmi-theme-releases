<?php
/**
 * Reusable template helpers: icons, breadcrumbs, product/project renderers.
 *
 * @package MMI_Technologies
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Small inline SVG icon library, used wherever a lightweight icon is needed
 * (feature cards, meta tags, placeholders) without pulling in an icon font.
 */
function mmi_icon( $name ) {
	$icons = array(
		'solar'      => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="12" cy="12" r="4" stroke="currentColor" stroke-width="1.8"/></svg>',
		'cctv'       => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 8l9-4 9 4-9 4-9-4z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M7 10.5V16c0 1 2.2 2 5 2s5-1 5-2v-5.5" stroke="currentColor" stroke-width="1.8"/></svg>',
		'it'         => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="4" width="18" height="12" rx="1.5" stroke="currentColor" stroke-width="1.8"/><path d="M8 20h8M12 16v4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
		'construction'=> '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 21h18M5 21V10l7-5 7 5v11" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M9 21v-6h6v6" stroke="currentColor" stroke-width="1.8"/></svg>',
		'supply'     => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 7l9-4 9 4-9 4-9-4z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M3 7v10l9 4 9-4V7M12 11v10" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
		'consultancy'=> '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="8" r="3.2" stroke="currentColor" stroke-width="1.8"/><path d="M4.5 20c1.4-3.6 4.3-5.5 7.5-5.5s6.1 1.9 7.5 5.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
		'design'     => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 19l4.5-1.1L19.4 7 17 4.6 6.1 15.5 5 20z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
		'innovation' => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 18h6M10 21h4M12 3a6 6 0 00-3.7 10.7c.5.4.7 1 .7 1.6V16h6v-.7c0-.6.2-1.2.7-1.6A6 6 0 0012 3z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
		'eco'        => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 22c5-2 8-6.5 8-12V5l-8-3-8 3v5c0 5.5 3 10 8 12z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M9 12l2 2 4-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'diversify'  => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="3" width="7" height="7" rx="1.2" stroke="currentColor" stroke-width="1.8"/><rect x="14" y="3" width="7" height="7" rx="1.2" stroke="currentColor" stroke-width="1.8"/><rect x="3" y="14" width="7" height="7" rx="1.2" stroke="currentColor" stroke-width="1.8"/><rect x="14" y="14" width="7" height="7" rx="1.2" stroke="currentColor" stroke-width="1.8"/></svg>',
		'network'    => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="5" cy="6" r="2.2" stroke="currentColor" stroke-width="1.8"/><circle cx="19" cy="6" r="2.2" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="18" r="2.2" stroke="currentColor" stroke-width="1.8"/><path d="M6.8 7.3L11 16M17.2 7.3L13 16" stroke="currentColor" stroke-width="1.8"/></svg>',
		'project'    => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 3h6v4H9z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M5 7h14v14H5z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M9 12h6M9 16h6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
		'pin'        => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 22s7-7.4 7-12.5A7 7 0 105 9.5C5 14.6 12 22 12 22z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><circle cx="12" cy="9.5" r="2.3" stroke="currentColor" stroke-width="1.8"/></svg>',
		'check'      => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'arrow'      => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'image'      => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="4" width="18" height="16" rx="1.5" stroke="currentColor" stroke-width="1.8"/><circle cx="8.5" cy="9.5" r="1.5" stroke="currentColor" stroke-width="1.8"/><path d="M21 16l-5.5-5.5L6 20" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
		'phone'      => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.6 10.8c1.4 2.8 3.8 5.2 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.6 21 3 13.4 3 4c0-.6.4-1 1-1h3.4c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
		'mail'       => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="5" width="18" height="14" rx="1.5" stroke="currentColor" stroke-width="1.6"/><path d="M4 6.5l8 6 8-6" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
		'clock'      => '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.6"/><path d="M12 7.5V12l3 2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
	);
	if ( isset( $icons[ $name ] ) ) {
		echo $icons[ $name ]; // phpcs:ignore WordPress.Security.EscapeOutput -- static, trusted inline SVG markup only.
	}
}

/**
 * Simple breadcrumb trail: Home / Current.
 */
function mmi_breadcrumbs() {
	echo '<nav class="mmi-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'mmi-tech' ) . '">';
	echo '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'mmi-tech' ) . '</a>';
	echo '<span class="mmi-breadcrumb-sep">/</span>';

	if ( is_singular( 'mmi_product' ) ) {
		echo '<a href="' . esc_url( mmi_get_products_page_url() ) . '">' . esc_html__( 'Products', 'mmi-tech' ) . '</a>';
		echo '<span class="mmi-breadcrumb-sep">/</span>';
		echo '<span>' . esc_html( get_the_title() ) . '</span>';
	} elseif ( is_singular( 'mmi_project' ) ) {
		echo '<a href="' . esc_url( mmi_get_projects_page_url() ) . '">' . esc_html__( 'Projects', 'mmi-tech' ) . '</a>';
		echo '<span class="mmi-breadcrumb-sep">/</span>';
		echo '<span>' . esc_html( get_the_title() ) . '</span>';
	} else {
		echo '<span>' . esc_html( get_the_title() ) . '</span>';
	}
	echo '</nav>';
}

/**
 * Resolve the URL of the Page currently using a given page template, falling
 * back to home if no such page exists yet (keeps things from fatally
 * erroring on a fresh install before the pages are created).
 */
function mmi_get_page_url_by_template( $template ) {
	static $cache = array();
	if ( isset( $cache[ $template ] ) ) {
		return $cache[ $template ];
	}
	$pages = get_posts( array(
		'post_type'      => 'page',
		'post_status'    => 'publish',
		'meta_key'       => '_wp_page_template',
		'meta_value'     => $template,
		'posts_per_page' => 1,
		'fields'         => 'ids',
	) );
	$url = $pages ? get_permalink( $pages[0] ) : home_url( '/' );
	$cache[ $template ] = $url;
	return $url;
}

function mmi_get_products_page_url() {
	return mmi_get_page_url_by_template( 'template-products.php' );
}

function mmi_get_projects_page_url() {
	return mmi_get_page_url_by_template( 'template-projects.php' );
}

function mmi_get_contact_page_url() {
	return mmi_get_page_url_by_template( 'template-contact.php' );
}

/**
 * A short, plain-text excerpt of the product description for card/listing use.
 */
function mmi_product_description_excerpt( $post_id, $word_count = 18 ) {
	$description = mmi_get_product_description( $post_id );
	if ( ! $description ) {
		return '';
	}
	$plain = wp_strip_all_tags( $description );
	return wp_trim_words( $plain, $word_count, '&hellip;' );
}

/**
 * Render the Products grid. Used by template-products.php, and reusable
 * anywhere else a product grid is wanted (e.g. a "related products" block).
 */
function mmi_render_products( $args = array() ) {
	$defaults = array(
		'posts_per_page' => -1,
		'category'       => '',
		'orderby'        => 'title',
		'order'          => 'ASC',
	);
	$args = wp_parse_args( $args, $defaults );

	$query_args = array(
		'post_type'      => 'mmi_product',
		'post_status'    => 'publish',
		'posts_per_page' => $args['posts_per_page'],
		'orderby'        => $args['orderby'],
		'order'          => $args['order'],
	);
	if ( $args['category'] ) {
		$query_args['tax_query'] = array(
			array(
				'taxonomy' => 'mmi_product_category',
				'field'    => 'slug',
				'terms'    => $args['category'],
			),
		);
	}

	$products = new WP_Query( $query_args );

	if ( ! $products->have_posts() ) {
		echo '<p class="mmi-empty-state">' . esc_html__( 'Products will be listed here soon. Please check back shortly.', 'mmi-tech' ) . '</p>';
		return;
	}

	echo '<div class="mmi-products-grid">';
	$mmi_card_i = 0;
	while ( $products->have_posts() ) {
		$products->the_post();
		$post_id     = get_the_ID();
		$status      = mmi_get_product_status( $post_id );
		$status_label= mmi_get_product_status_label( $post_id );
		$terms       = get_the_terms( $post_id, 'mmi_product_category' );
		$category    = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
		$excerpt     = mmi_product_description_excerpt( $post_id );
		// Stagger the scroll-reveal animation slightly per card, capped so a
		// long grid doesn't leave the last cards waiting ages to appear.
		$mmi_delay_ms = min( $mmi_card_i * 60, 300 );
		$mmi_card_i++;
		?>
		<article class="mmi-product-card mmi-reveal" style="transition-delay: <?php echo esc_attr( $mmi_delay_ms ); ?>ms;">
			<a href="<?php the_permalink(); ?>" class="mmi-card-media">
				<span class="stock-badge stock-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $status_label ); ?></span>
				<?php if ( has_post_thumbnail() ) : ?>
					<?php the_post_thumbnail( 'mmi-card' ); ?>
				<?php else : ?>
					<span class="media-placeholder"><?php mmi_icon( 'it' ); ?></span>
				<?php endif; ?>
			</a>
			<div class="mmi-card-body">
				<?php if ( $category ) : ?>
					<span class="mmi-card-eyebrow"><?php echo esc_html( $category ); ?></span>
				<?php endif; ?>
				<h3 class="mmi-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<?php if ( $excerpt ) : ?>
					<p class="mmi-card-excerpt"><?php echo esc_html( $excerpt ); ?></p>
				<?php endif; ?>
				<div class="mmi-card-actions">
					<a href="<?php the_permalink(); ?>" class="btn btn-outline btn-sm"><?php esc_html_e( 'View Details', 'mmi-tech' ); ?></a>
					<a href="<?php echo esc_url( mmi_whatsapp_url( sprintf( __( 'Hello, I would like to request the price of %s.', 'mmi-tech' ), get_the_title() ) ) ); ?>" class="btn btn-primary btn-sm" target="_blank" rel="noopener"><?php esc_html_e( 'Request Price', 'mmi-tech' ); ?></a>
				</div>
			</div>
		</article>
		<?php
	}
	echo '</div>';
	wp_reset_postdata();
}

/**
 * Render the Projects grid. Used by template-projects.php.
 */
function mmi_render_projects( $args = array() ) {
	$defaults = array(
		'posts_per_page' => -1,
		'orderby'        => 'date',
		'order'          => 'DESC',
	);
	$args = wp_parse_args( $args, $defaults );

	$projects = new WP_Query( array(
		'post_type'      => 'mmi_project',
		'post_status'    => 'publish',
		'posts_per_page' => $args['posts_per_page'],
		'orderby'        => $args['orderby'],
		'order'          => $args['order'],
	) );

	if ( ! $projects->have_posts() ) {
		echo '<p class="mmi-empty-state">' . esc_html__( 'Projects will be listed here soon. Please check back shortly.', 'mmi-tech' ) . '</p>';
		return;
	}

	echo '<div class="mmi-projects-grid">';
	$mmi_card_i = 0;
	while ( $projects->have_posts() ) {
		$projects->the_post();
		$post_id  = get_the_ID();
		$type     = mmi_get_project_type( $post_id );
		$location = mmi_get_project_location( $post_id );
		$mmi_delay_ms = min( $mmi_card_i * 60, 300 );
		$mmi_card_i++;
		?>
		<article class="mmi-project-card mmi-reveal" style="transition-delay: <?php echo esc_attr( $mmi_delay_ms ); ?>ms;">
			<a href="<?php the_permalink(); ?>" class="mmi-card-media">
				<?php if ( has_post_thumbnail() ) : ?>
					<?php the_post_thumbnail( 'mmi-card' ); ?>
				<?php else : ?>
					<span class="media-placeholder"><?php mmi_icon( 'project' ); ?></span>
				<?php endif; ?>
			</a>
			<div class="mmi-card-body">
				<h3 class="mmi-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<?php if ( $type || $location ) : ?>
					<div class="project-meta-row">
						<?php if ( $type ) : ?>
							<span class="project-meta-tag"><?php mmi_icon( 'project' ); ?><?php echo esc_html( $type ); ?></span>
						<?php endif; ?>
						<?php if ( $location ) : ?>
							<span class="project-meta-tag"><?php mmi_icon( 'pin' ); ?><?php echo esc_html( $location ); ?></span>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<a href="<?php the_permalink(); ?>" class="btn btn-outline btn-sm"><?php esc_html_e( 'View Project', 'mmi-tech' ); ?></a>
			</div>
		</article>
		<?php
	}
	echo '</div>';
	wp_reset_postdata();
}
