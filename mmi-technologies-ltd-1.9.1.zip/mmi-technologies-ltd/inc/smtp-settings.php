<?php
/**
 * Settings > MMI Email — SMTP delivery settings.
 *
 * PHP's built-in mail() function is unreliable/disabled on some shared
 * hosting, which is why Contact form enquiries were not reaching your inbox.
 * This screen lets you configure a real SMTP connection (e.g. Gmail, your
 * hosting provider's SMTP, or a transactional email service). Once enabled,
 * outgoing mail goes out over that SMTP connection directly and does not
 * depend on the host's mail() function at all.
 *
 * Credentials you enter here are only ever visible to Administrators (this
 * page requires the manage_options capability) and are stored the same way
 * any standard WordPress plugin setting is stored.
 *
 * @package MMI_Technologies
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MMI_SMTP_OPTION', 'mmi_smtp_settings' );

/**
 * Default settings shape.
 */
function mmi_smtp_default_settings() {
	return array(
		'enabled'        => '0',
		'host'           => '',
		'port'           => '587',
		'encryption'     => 'tls', // 'tls', 'ssl', or 'none'.
		'username'       => '',
		'password'       => '',
		'from_email'     => '',
		'from_name'      => get_bloginfo( 'name' ),
		'notify_email'   => 'mmitechnologies1@gmail.com',
	);
}

function mmi_smtp_get_settings() {
	$saved = get_option( MMI_SMTP_OPTION, array() );
	return wp_parse_args( $saved, mmi_smtp_default_settings() );
}

function mmi_smtp_is_enabled() {
	$settings = mmi_smtp_get_settings();
	return '1' === $settings['enabled'] && ! empty( $settings['host'] ) && ! empty( $settings['username'] );
}

/**
 * The address enquiry notifications should be sent to. Falls back to the
 * site's admin email if no override has been set.
 */
function mmi_get_notification_email() {
	$settings = mmi_smtp_get_settings();
	if ( ! empty( $settings['notify_email'] ) && is_email( $settings['notify_email'] ) ) {
		return $settings['notify_email'];
	}
	return get_option( 'admin_email' );
}

/**
 * Register the Settings > MMI Email screen.
 */
function mmi_smtp_admin_menu() {
	add_options_page(
		__( 'MMI Email Settings', 'mmi-tech' ),
		__( 'MMI Email', 'mmi-tech' ),
		'manage_options',
		'mmi-email-settings',
		'mmi_smtp_settings_page'
	);
}
add_action( 'admin_menu', 'mmi_smtp_admin_menu' );

function mmi_smtp_register_settings() {
	register_setting( 'mmi_smtp_settings_group', MMI_SMTP_OPTION, array(
		'sanitize_callback' => 'mmi_smtp_sanitize_settings',
	) );
}
add_action( 'admin_init', 'mmi_smtp_register_settings' );

function mmi_smtp_sanitize_settings( $input ) {
	$existing = mmi_smtp_get_settings();
	$output   = array();

	$output['enabled']      = ! empty( $input['enabled'] ) ? '1' : '0';
	$output['host']         = isset( $input['host'] ) ? sanitize_text_field( wp_unslash( $input['host'] ) ) : '';
	$output['port']         = isset( $input['port'] ) ? absint( $input['port'] ) : 587;
	$output['encryption']   = isset( $input['encryption'] ) && in_array( $input['encryption'], array( 'tls', 'ssl', 'none' ), true ) ? $input['encryption'] : 'tls';
	$output['username']     = isset( $input['username'] ) ? sanitize_text_field( wp_unslash( $input['username'] ) ) : '';
	$output['from_email']   = isset( $input['from_email'] ) ? sanitize_email( wp_unslash( $input['from_email'] ) ) : '';
	$output['from_name']    = isset( $input['from_name'] ) ? sanitize_text_field( wp_unslash( $input['from_name'] ) ) : get_bloginfo( 'name' );
	$output['notify_email'] = isset( $input['notify_email'] ) ? sanitize_email( wp_unslash( $input['notify_email'] ) ) : 'mmitechnologies1@gmail.com';

	// Only overwrite the stored password if a new one was actually typed —
	// the settings form always renders the password field blank, so an
	// empty submission means "leave it as it was", not "clear it".
	if ( ! empty( $input['password'] ) ) {
		$output['password'] = $input['password'];
	} else {
		$output['password'] = $existing['password'];
	}

	return $output;
}

function mmi_smtp_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$settings = mmi_smtp_get_settings();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'MMI Email Settings', 'mmi-tech' ); ?></h1>
		<p><?php esc_html_e( 'Configure SMTP so Contact form enquiries reliably reach your inbox, even if this host\'s built-in mail() function is disabled or unreliable.', 'mmi-tech' ); ?></p>

		<?php if ( isset( $_GET['mmi_test_sent'] ) ) : ?>
			<?php if ( '1' === $_GET['mmi_test_sent'] ) : ?>
				<div class="notice notice-success"><p><?php esc_html_e( 'Test email sent successfully. Check the inbox above.', 'mmi-tech' ); ?></p></div>
			<?php else : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'The test email could not be sent. Double-check your SMTP details and try again.', 'mmi-tech' ); ?></p></div>
			<?php endif; ?>
		<?php endif; ?>

		<form method="post" action="options.php">
			<?php settings_fields( 'mmi_smtp_settings_group' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable SMTP', 'mmi-tech' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="<?php echo esc_attr( MMI_SMTP_OPTION ); ?>[enabled]" value="1" <?php checked( $settings['enabled'], '1' ); ?>>
							<?php esc_html_e( 'Send outgoing mail through the SMTP connection below', 'mmi-tech' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="mmi_smtp_host"><?php esc_html_e( 'SMTP Host', 'mmi-tech' ); ?></label></th>
					<td><input type="text" id="mmi_smtp_host" name="<?php echo esc_attr( MMI_SMTP_OPTION ); ?>[host]" value="<?php echo esc_attr( $settings['host'] ); ?>" class="regular-text" placeholder="smtp.gmail.com"></td>
				</tr>
				<tr>
					<th scope="row"><label for="mmi_smtp_port"><?php esc_html_e( 'SMTP Port', 'mmi-tech' ); ?></label></th>
					<td><input type="number" id="mmi_smtp_port" name="<?php echo esc_attr( MMI_SMTP_OPTION ); ?>[port]" value="<?php echo esc_attr( $settings['port'] ); ?>" class="small-text"></td>
				</tr>
				<tr>
					<th scope="row"><label for="mmi_smtp_encryption"><?php esc_html_e( 'Encryption', 'mmi-tech' ); ?></label></th>
					<td>
						<select id="mmi_smtp_encryption" name="<?php echo esc_attr( MMI_SMTP_OPTION ); ?>[encryption]">
							<option value="tls" <?php selected( $settings['encryption'], 'tls' ); ?>>TLS (<?php esc_html_e( 'recommended, usually port 587', 'mmi-tech' ); ?>)</option>
							<option value="ssl" <?php selected( $settings['encryption'], 'ssl' ); ?>>SSL (<?php esc_html_e( 'usually port 465', 'mmi-tech' ); ?>)</option>
							<option value="none" <?php selected( $settings['encryption'], 'none' ); ?>><?php esc_html_e( 'None', 'mmi-tech' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="mmi_smtp_username"><?php esc_html_e( 'SMTP Username', 'mmi-tech' ); ?></label></th>
					<td><input type="text" id="mmi_smtp_username" name="<?php echo esc_attr( MMI_SMTP_OPTION ); ?>[username]" value="<?php echo esc_attr( $settings['username'] ); ?>" class="regular-text" autocomplete="off"></td>
				</tr>
				<tr>
					<th scope="row"><label for="mmi_smtp_password"><?php esc_html_e( 'SMTP Password', 'mmi-tech' ); ?></label></th>
					<td>
						<input type="password" id="mmi_smtp_password" name="<?php echo esc_attr( MMI_SMTP_OPTION ); ?>[password]" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo $settings['password'] ? esc_attr__( '(unchanged)', 'mmi-tech' ) : ''; ?>">
						<p class="description"><?php esc_html_e( 'For Gmail, use a 16-character Google App Password, not your normal account password (your Google Account needs 2-Step Verification turned on to create one). Leave blank to keep the currently saved password.', 'mmi-tech' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="mmi_smtp_from_email"><?php esc_html_e( '"From" Email', 'mmi-tech' ); ?></label></th>
					<td><input type="email" id="mmi_smtp_from_email" name="<?php echo esc_attr( MMI_SMTP_OPTION ); ?>[from_email]" value="<?php echo esc_attr( $settings['from_email'] ); ?>" class="regular-text" placeholder="mmitechnologies1@gmail.com"></td>
				</tr>
				<tr>
					<th scope="row"><label for="mmi_smtp_from_name"><?php esc_html_e( '"From" Name', 'mmi-tech' ); ?></label></th>
					<td><input type="text" id="mmi_smtp_from_name" name="<?php echo esc_attr( MMI_SMTP_OPTION ); ?>[from_name]" value="<?php echo esc_attr( $settings['from_name'] ); ?>" class="regular-text"></td>
				</tr>
				<tr>
					<th scope="row"><label for="mmi_smtp_notify_email"><?php esc_html_e( 'Send Enquiries To', 'mmi-tech' ); ?></label></th>
					<td>
						<input type="email" id="mmi_smtp_notify_email" name="<?php echo esc_attr( MMI_SMTP_OPTION ); ?>[notify_email]" value="<?php echo esc_attr( $settings['notify_email'] ); ?>" class="regular-text">
						<p class="description"><?php esc_html_e( 'The inbox that new Contact form enquiries should be emailed to.', 'mmi-tech' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Save Settings', 'mmi-tech' ) ); ?>
		</form>

		<hr>
		<h2><?php esc_html_e( 'Send a Test Email', 'mmi-tech' ); ?></h2>
		<p><?php esc_html_e( 'Save your settings above first, then use this to confirm delivery actually works before relying on it.', 'mmi-tech' ); ?></p>
		<form method="post">
			<?php wp_nonce_field( 'mmi_smtp_test_email', 'mmi_smtp_test_nonce' ); ?>
			<input type="hidden" name="mmi_form" value="smtp_test">
			<?php submit_button( __( 'Send Test Email', 'mmi-tech' ), 'secondary', 'submit', false ); ?>
		</form>
	</div>
	<?php
}

/**
 * Handle the "Send Test Email" button.
 */
function mmi_smtp_handle_test_email() {
	if ( empty( $_POST['mmi_form'] ) || 'smtp_test' !== $_POST['mmi_form'] ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! isset( $_POST['mmi_smtp_test_nonce'] ) || ! wp_verify_nonce( $_POST['mmi_smtp_test_nonce'], 'mmi_smtp_test_email' ) ) {
		return;
	}

	$to      = mmi_get_notification_email();
	$subject = __( 'MMI Technologies — Test Email', 'mmi-tech' );
	$body    = __( 'If you are reading this, your SMTP email settings are working correctly.', 'mmi-tech' );
	$sent    = wp_mail( $to, $subject, $body );

	wp_safe_redirect( add_query_arg( 'mmi_test_sent', $sent ? '1' : '0', admin_url( 'options-general.php?page=mmi-email-settings' ) ) );
	exit;
}
add_action( 'admin_init', 'mmi_smtp_handle_test_email' );

/**
 * Route outgoing mail through the configured SMTP connection, when enabled.
 */
function mmi_smtp_phpmailer_init( $phpmailer ) {
	if ( ! mmi_smtp_is_enabled() ) {
		return;
	}
	$settings = mmi_smtp_get_settings();

	$phpmailer->isSMTP();
	$phpmailer->Host       = $settings['host'];
	$phpmailer->Port       = (int) $settings['port'];
	$phpmailer->SMTPAuth   = true;
	$phpmailer->Username   = $settings['username'];
	$phpmailer->Password   = $settings['password'];

	if ( 'none' === $settings['encryption'] ) {
		$phpmailer->SMTPSecure = '';
		$phpmailer->SMTPAutoTLS = false;
	} else {
		$phpmailer->SMTPSecure = $settings['encryption']; // 'tls' or 'ssl'.
	}

	if ( ! empty( $settings['from_email'] ) && is_email( $settings['from_email'] ) ) {
		$phpmailer->setFrom( $settings['from_email'], $settings['from_name'] );
	}
}
add_action( 'phpmailer_init', 'mmi_smtp_phpmailer_init' );

/**
 * Make sure wp_mail() failures surface a useful reason in the debug log
 * instead of failing silently, which makes the Test Email button far more
 * useful when something is misconfigured.
 */
add_action( 'wp_mail_failed', function ( $wp_error ) {
	if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
		error_log( 'MMI SMTP: wp_mail failed — ' . $wp_error->get_error_message() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
	}
} );
