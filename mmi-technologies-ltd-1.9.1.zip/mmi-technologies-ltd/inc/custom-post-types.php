<?php
/**
 * Custom Post Types: Products & Projects.
 * Plus their taxonomies, admin meta boxes, and post-meta helper accessors.
 *
 * @package MMI_Technologies
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* -------------------------------------------------------------------------
 * Registration
 * ---------------------------------------------------------------------- */

function mmi_register_post_types() {

	// Products.
	register_post_type( 'mmi_product', array(
		'labels' => array(
			'name'               => __( 'Products', 'mmi-tech' ),
			'singular_name'      => __( 'Product', 'mmi-tech' ),
			'add_new_item'       => __( 'Add New Product', 'mmi-tech' ),
			'edit_item'          => __( 'Edit Product', 'mmi-tech' ),
			'new_item'           => __( 'New Product', 'mmi-tech' ),
			'view_item'          => __( 'View Product', 'mmi-tech' ),
			'search_items'       => __( 'Search Products', 'mmi-tech' ),
			'not_found'          => __( 'No products found', 'mmi-tech' ),
			'not_found_in_trash' => __( 'No products found in Trash', 'mmi-tech' ),
			'all_items'          => __( 'All Products', 'mmi-tech' ),
			'menu_name'          => __( 'Products', 'mmi-tech' ),
		),
		'public'             => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_icon'          => 'dashicons-cart',
		'menu_position'      => 20,
		'supports'           => array( 'title', 'thumbnail' ),
		'has_archive'        => false,
		'rewrite'            => array( 'slug' => 'product', 'with_front' => false ),
		'show_in_rest'       => false,
		'publicly_queryable' => true,
		'exclude_from_search'=> false,
	) );

	// Product category taxonomy.
	register_taxonomy( 'mmi_product_category', 'mmi_product', array(
		'labels' => array(
			'name'          => __( 'Product Categories', 'mmi-tech' ),
			'singular_name' => __( 'Product Category', 'mmi-tech' ),
			'search_items'  => __( 'Search Categories', 'mmi-tech' ),
			'all_items'     => __( 'All Categories', 'mmi-tech' ),
			'edit_item'     => __( 'Edit Category', 'mmi-tech' ),
			'update_item'   => __( 'Update Category', 'mmi-tech' ),
			'add_new_item'  => __( 'Add New Category', 'mmi-tech' ),
			'new_item_name' => __( 'New Category Name', 'mmi-tech' ),
			'menu_name'     => __( 'Categories', 'mmi-tech' ),
		),
		'hierarchical'      => true,
		'show_ui'           => true,
		'show_admin_column' => true,
		'show_in_rest'      => false,
		'rewrite'           => array( 'slug' => 'product-category', 'with_front' => false ),
	) );

	// Projects.
	register_post_type( 'mmi_project', array(
		'labels' => array(
			'name'               => __( 'Projects', 'mmi-tech' ),
			'singular_name'      => __( 'Project', 'mmi-tech' ),
			'add_new_item'       => __( 'Add New Project', 'mmi-tech' ),
			'edit_item'          => __( 'Edit Project', 'mmi-tech' ),
			'new_item'           => __( 'New Project', 'mmi-tech' ),
			'view_item'          => __( 'View Project', 'mmi-tech' ),
			'search_items'       => __( 'Search Projects', 'mmi-tech' ),
			'not_found'          => __( 'No projects found', 'mmi-tech' ),
			'not_found_in_trash' => __( 'No projects found in Trash', 'mmi-tech' ),
			'all_items'          => __( 'All Projects', 'mmi-tech' ),
			'menu_name'          => __( 'Projects', 'mmi-tech' ),
		),
		'public'             => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_icon'          => 'dashicons-hammer',
		'menu_position'      => 21,
		'supports'           => array( 'title', 'editor', 'thumbnail' ),
		'has_archive'        => false,
		'rewrite'            => array( 'slug' => 'project', 'with_front' => false ),
		'show_in_rest'       => false,
		'publicly_queryable' => true,
		'exclude_from_search'=> false,
	) );
}
add_action( 'init', 'mmi_register_post_types' );

/**
 * Flush rewrite rules once on theme activation only (standard WP CPT
 * boilerplate — this is the ONLY thing that runs automatically on
 * activation; there is no page/menu/image automation in this theme).
 */
function mmi_flush_rewrites_on_switch() {
	mmi_register_post_types();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'mmi_flush_rewrites_on_switch' );

/* -------------------------------------------------------------------------
 * Admin columns: show status / type / location at a glance in the list tables
 * ---------------------------------------------------------------------- */

add_filter( 'manage_mmi_product_posts_columns', function( $columns ) {
	$columns['mmi_status'] = __( 'Availability', 'mmi-tech' );
	return $columns;
} );
add_action( 'manage_mmi_product_posts_custom_column', function( $column, $post_id ) {
	if ( 'mmi_status' === $column ) {
		echo esc_html( mmi_get_product_status_label( $post_id ) );
	}
}, 10, 2 );

add_filter( 'manage_mmi_project_posts_columns', function( $columns ) {
	$columns['mmi_type']     = __( 'Project Type', 'mmi-tech' );
	$columns['mmi_location'] = __( 'Location', 'mmi-tech' );
	return $columns;
} );
add_action( 'manage_mmi_project_posts_custom_column', function( $column, $post_id ) {
	if ( 'mmi_type' === $column ) {
		echo esc_html( mmi_get_project_type( $post_id ) );
	}
	if ( 'mmi_location' === $column ) {
		echo esc_html( mmi_get_project_location( $post_id ) );
	}
}, 10, 2 );

/* -------------------------------------------------------------------------
 * Meta boxes: Products
 * ---------------------------------------------------------------------- */

function mmi_product_meta_boxes() {
	add_meta_box(
		'mmi_product_status',
		__( 'Availability', 'mmi-tech' ),
		'mmi_product_status_cb',
		'mmi_product',
		'side',
		'default'
	);
	add_meta_box(
		'mmi_product_description',
		__( 'Product Description', 'mmi-tech' ),
		'mmi_product_description_cb',
		'mmi_product',
		'normal',
		'high'
	);
	add_meta_box(
		'mmi_product_gallery',
		__( 'Additional Product Images', 'mmi-tech' ),
		'mmi_gallery_metabox_cb',
		'mmi_product',
		'normal',
		'default',
		array( 'meta_key' => '_mmi_product_gallery' )
	);
}
add_action( 'add_meta_boxes', 'mmi_product_meta_boxes' );

function mmi_product_status_cb( $post ) {
	wp_nonce_field( 'mmi_save_product_meta', 'mmi_product_meta_nonce' );
	$status = mmi_get_product_status( $post->ID );
	?>
	<label for="mmi_product_status_field" class="screen-reader-text"><?php esc_html_e( 'Availability', 'mmi-tech' ); ?></label>
	<select name="mmi_product_status_field" id="mmi_product_status_field" style="width:100%;">
		<option value="in_stock" <?php selected( $status, 'in_stock' ); ?>><?php esc_html_e( 'In Stock', 'mmi-tech' ); ?></option>
		<option value="out_of_stock" <?php selected( $status, 'out_of_stock' ); ?>><?php esc_html_e( 'Out of Stock', 'mmi-tech' ); ?></option>
	</select>
	<?php
}

/**
 * Product Description meta box.
 *
 * Deliberately a dedicated field (stored in post meta) rather than reusing
 * the main content editor, so the admin screen has one obvious place to
 * enter what shows on the listing and single product pages.
 */
function mmi_product_description_cb( $post ) {
	wp_nonce_field( 'mmi_save_product_meta', 'mmi_product_meta_nonce' );
	$description = get_post_meta( $post->ID, '_mmi_product_description', true );
	echo '<p class="description" style="margin-top:0;">' . esc_html__( 'This description appears on the Products listing page (shortened) and on this product\'s own detail page (in full).', 'mmi-tech' ) . '</p>';
	wp_editor(
		$description,
		'mmi_product_description_field',
		array(
			'textarea_name' => 'mmi_product_description_field',
			'textarea_rows' => 8,
			'media_buttons' => false,
			'teeny'         => true,
			'quicktags'     => true,
		)
	);
}

function mmi_save_product_meta( $post_id ) {
	if ( ! isset( $_POST['mmi_product_meta_nonce'] ) || ! wp_verify_nonce( $_POST['mmi_product_meta_nonce'], 'mmi_save_product_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( isset( $_POST['mmi_product_status_field'] ) ) {
		$status = sanitize_key( $_POST['mmi_product_status_field'] );
		if ( ! in_array( $status, array( 'in_stock', 'out_of_stock' ), true ) ) {
			$status = 'in_stock';
		}
		update_post_meta( $post_id, '_mmi_product_status', $status );
	}

	if ( isset( $_POST['mmi_product_description_field'] ) ) {
		$description = wp_kses_post( wp_unslash( $_POST['mmi_product_description_field'] ) );
		update_post_meta( $post_id, '_mmi_product_description', $description );
	}

	mmi_save_gallery_meta( $post_id, '_mmi_product_gallery' );
}
add_action( 'save_post_mmi_product', 'mmi_save_product_meta' );

function mmi_get_product_status( $post_id ) {
	$status = get_post_meta( $post_id, '_mmi_product_status', true );
	return $status ? $status : 'in_stock';
}

function mmi_get_product_status_label( $post_id ) {
	return 'out_of_stock' === mmi_get_product_status( $post_id )
		? __( 'Out of Stock', 'mmi-tech' )
		: __( 'In Stock', 'mmi-tech' );
}

function mmi_get_product_description( $post_id ) {
	return get_post_meta( $post_id, '_mmi_product_description', true );
}

/* -------------------------------------------------------------------------
 * Meta boxes: Projects
 * ---------------------------------------------------------------------- */

function mmi_project_meta_boxes() {
	add_meta_box(
		'mmi_project_details',
		__( 'Project Details', 'mmi-tech' ),
		'mmi_project_details_cb',
		'mmi_project',
		'side',
		'default'
	);
	add_meta_box(
		'mmi_project_gallery',
		__( 'Additional Project Images', 'mmi-tech' ),
		'mmi_gallery_metabox_cb',
		'mmi_project',
		'normal',
		'default',
		array( 'meta_key' => '_mmi_project_gallery' )
	);
}
add_action( 'add_meta_boxes', 'mmi_project_meta_boxes' );

function mmi_project_details_cb( $post ) {
	wp_nonce_field( 'mmi_save_project_meta', 'mmi_project_meta_nonce' );
	$type     = mmi_get_project_type( $post->ID );
	$location = mmi_get_project_location( $post->ID );
	?>
	<p>
		<label for="mmi_project_type_field"><strong><?php esc_html_e( 'Project Type', 'mmi-tech' ); ?></strong></label><br>
		<input type="text" id="mmi_project_type_field" name="mmi_project_type_field" style="width:100%;" value="<?php echo esc_attr( $type ); ?>" placeholder="<?php esc_attr_e( 'e.g. Street Lighting', 'mmi-tech' ); ?>">
	</p>
	<p>
		<label for="mmi_project_location_field"><strong><?php esc_html_e( 'Location', 'mmi-tech' ); ?></strong></label><br>
		<input type="text" id="mmi_project_location_field" name="mmi_project_location_field" style="width:100%;" value="<?php echo esc_attr( $location ); ?>" placeholder="<?php esc_attr_e( 'e.g. Ilorin, Kwara State', 'mmi-tech' ); ?>">
	</p>
	<?php
}

function mmi_save_project_meta( $post_id ) {
	if ( ! isset( $_POST['mmi_project_meta_nonce'] ) || ! wp_verify_nonce( $_POST['mmi_project_meta_nonce'], 'mmi_save_project_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( isset( $_POST['mmi_project_type_field'] ) ) {
		update_post_meta( $post_id, '_mmi_project_type', sanitize_text_field( wp_unslash( $_POST['mmi_project_type_field'] ) ) );
	}
	if ( isset( $_POST['mmi_project_location_field'] ) ) {
		update_post_meta( $post_id, '_mmi_project_location', sanitize_text_field( wp_unslash( $_POST['mmi_project_location_field'] ) ) );
	}

	mmi_save_gallery_meta( $post_id, '_mmi_project_gallery' );
}
add_action( 'save_post_mmi_project', 'mmi_save_project_meta' );

function mmi_get_project_type( $post_id ) {
	return get_post_meta( $post_id, '_mmi_project_type', true );
}

function mmi_get_project_location( $post_id ) {
	return get_post_meta( $post_id, '_mmi_project_location', true );
}

/* -------------------------------------------------------------------------
 * Shared gallery meta box (used by both Products and Projects)
 * ---------------------------------------------------------------------- */

function mmi_gallery_metabox_cb( $post, $box ) {
	$meta_key = isset( $box['args']['meta_key'] ) ? $box['args']['meta_key'] : '_mmi_gallery';

	wp_enqueue_media();
	wp_enqueue_script(
		'mmi-admin-gallery',
		MMI_THEME_URI . '/assets/js/admin-gallery.js',
		array( 'jquery' ),
		MMI_THEME_VERSION,
		true
	);

	$ids = mmi_get_gallery_ids( $post->ID, $meta_key );
	?>
	<div class="mmi-gallery-field" data-meta-key="<?php echo esc_attr( $meta_key ); ?>">
		<input type="hidden" class="mmi-gallery-ids" name="<?php echo esc_attr( $meta_key ); ?>_field" value="<?php echo esc_attr( implode( ',', $ids ) ); ?>">
		<div class="mmi-gallery-preview" style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:10px;">
			<?php foreach ( $ids as $attachment_id ) : ?>
				<?php $thumb = wp_get_attachment_image_src( $attachment_id, 'thumbnail' ); ?>
				<?php if ( $thumb ) : ?>
					<div class="mmi-gallery-item" data-id="<?php echo esc_attr( $attachment_id ); ?>" style="position:relative;">
						<img src="<?php echo esc_url( $thumb[0] ); ?>" style="width:80px;height:80px;object-fit:cover;border-radius:4px;border:1px solid #ddd;">
						<button type="button" class="mmi-gallery-remove" style="position:absolute;top:-8px;right:-8px;background:#d63638;color:#fff;border:none;border-radius:50%;width:20px;height:20px;line-height:18px;cursor:pointer;">&times;</button>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<button type="button" class="button mmi-gallery-add"><?php esc_html_e( 'Add Images', 'mmi-tech' ); ?></button>
	</div>
	<?php
}

function mmi_save_gallery_meta( $post_id, $meta_key ) {
	$field_name = $meta_key . '_field';
	if ( ! isset( $_POST[ $field_name ] ) ) {
		return;
	}
	$raw = sanitize_text_field( wp_unslash( $_POST[ $field_name ] ) );
	$ids = array_filter( array_map( 'absint', explode( ',', $raw ) ) );
	update_post_meta( $post_id, $meta_key, array_values( $ids ) );
}

function mmi_get_gallery_ids( $post_id, $meta_key ) {
	$ids = get_post_meta( $post_id, $meta_key, true );
	return is_array( $ids ) ? array_map( 'absint', $ids ) : array();
}
