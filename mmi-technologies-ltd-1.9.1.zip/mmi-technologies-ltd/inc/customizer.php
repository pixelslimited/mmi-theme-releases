<?php
/**
 * Customizer: brand color + a couple of small site-wide text options.
 *
 * @package MMI_Technologies
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mmi_customize_register( $wp_customize ) {

	// Section: Brand.
	$wp_customize->add_section( 'mmi_brand', array(
		'title'    => __( 'MMI Brand Settings', 'mmi-tech' ),
		'priority' => 30,
	) );

	// Primary brand color.
	$wp_customize->add_setting( 'mmi_color_primary', array(
		'default'           => '#0B7FE0',
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mmi_color_primary_control', array(
		'label'       => __( 'Primary Brand Color', 'mmi-tech' ),
		'description' => __( 'The main brand blue used across buttons, links, and accents.', 'mmi-tech' ),
		'section'     => 'mmi_brand',
		'settings'    => 'mmi_color_primary',
	) ) );

	// Tagline under the logo lockup in the header.
	$wp_customize->add_setting( 'mmi_header_tagline', array(
		'default'           => 'Innovation is our tradition',
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'mmi_header_tagline_control', array(
		'label'    => __( 'Header Tagline', 'mmi-tech' ),
		'section'  => 'mmi_brand',
		'settings' => 'mmi_header_tagline',
		'type'     => 'text',
	) );

	// WhatsApp number used by the floating chat button and CTAs (digits only, with country code).
	$wp_customize->add_setting( 'mmi_whatsapp_number', array(
		'default'           => '2347019448554',
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'mmi_whatsapp_number_control', array(
		'label'       => __( 'WhatsApp Number', 'mmi-tech' ),
		'description' => __( 'Digits only, with country code, e.g. 2347019448554', 'mmi-tech' ),
		'section'     => 'mmi_brand',
		'settings'    => 'mmi_whatsapp_number',
		'type'        => 'text',
	) );
}
add_action( 'customize_register', 'mmi_customize_register' );

/**
 * Output the chosen primary color as inline CSS custom properties.
 */
function mmi_customizer_inline_css() {
	$color = get_theme_mod( 'mmi_color_primary', '#0B7FE0' );
	if ( ! $color ) {
		$color = '#0B7FE0';
	}
	?>
	<style id="mmi-customizer-inline-css">
		:root {
			--color-primary: <?php echo esc_html( $color ); ?>;
		}
	</style>
	<?php
}
add_action( 'wp_head', 'mmi_customizer_inline_css' );

/**
 * Small helper to get the WhatsApp link anywhere in the theme.
 */
function mmi_whatsapp_url( $message = '' ) {
	$number = get_theme_mod( 'mmi_whatsapp_number', '2347019448554' );
	$number = preg_replace( '/[^0-9]/', '', (string) $number );
	if ( '' === $message ) {
		$message = __( 'Hello MMI Technologies Ltd, I would like to make an enquiry about your services.', 'mmi-tech' );
	}
	return 'https://wa.me/' . $number . '?text=' . rawurlencode( $message );
}
