<?php
/**
 * Staff dashboard: back-end logic for enquiry status/replies and comment
 * moderation. The actual page markup lives in template-staff-dashboard.php;
 * this file only handles data + the POST actions it submits.
 *
 * Every form field here is deliberately prefixed "mmi_" — see the note at
 * the top of inc/forms-handler.php for why a bare "name"-style field can
 * break WordPress's own request routing. None of the names below collide
 * with WordPress's reserved public query vars.
 *
 * @package MMI_Technologies
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* -------------------------------------------------------------------------
 * Data helpers
 * ---------------------------------------------------------------------- */

/**
 * Fetch enquiries for the dashboard list.
 *
 * @param string $status 'all', 'pending', or 'responded'.
 */
function mmi_get_enquiries_for_dashboard( $status = 'all', $limit = 50 ) {
	$args = array(
		'post_type'      => 'mmi_enquiry',
		'post_status'    => 'private',
		'posts_per_page' => $limit,
		'orderby'        => 'date',
		'order'          => 'DESC',
	);
	if ( in_array( $status, array( 'pending', 'responded' ), true ) ) {
		$args['meta_query'] = array(
			array(
				'key'   => '_mmi_enquiry_status',
				'value' => $status,
			),
		);
		// "Pending" also has to match enquiries logged before this field
		// existed (no meta row at all yet).
		if ( 'pending' === $status ) {
			$args['meta_query'] = array(
				'relation' => 'OR',
				array(
					'key'   => '_mmi_enquiry_status',
					'value' => 'pending',
				),
				array(
					'key'     => '_mmi_enquiry_status',
					'compare' => 'NOT EXISTS',
				),
			);
		}
	}
	return get_posts( $args );
}

/**
 * Replies staff have sent for a given enquiry, stored as native WordPress
 * comments on the (private) enquiry post — oldest first.
 */
function mmi_get_enquiry_replies( $enquiry_id ) {
	return get_comments( array(
		'post_id' => $enquiry_id,
		'type'    => 'mmi_staff_reply',
		'status'  => 'approve',
		'order'   => 'ASC',
	) );
}

/**
 * Recent site comments (any post type) for the Comments moderation tab.
 */
function mmi_get_recent_comments_for_dashboard( $limit = 50 ) {
	return get_comments( array(
		'number' => $limit,
		'type'   => 'comment', // Exclude our own 'mmi_staff_reply' type from this list.
		'status' => 'all',
	) );
}

/* -------------------------------------------------------------------------
 * POST action handling
 * ---------------------------------------------------------------------- */

function mmi_dashboard_handle_actions() {
	if ( empty( $_POST['mmi_form'] ) ) {
		return;
	}
	$form = sanitize_key( $_POST['mmi_form'] );

	if ( ! in_array( $form, array( 'dashboard_status', 'dashboard_reply', 'dashboard_comment' ), true ) ) {
		return;
	}

	// Every dashboard action requires a logged-in Staff/Admin user.
	if ( ! mmi_current_user_is_staff() ) {
		wp_die( esc_html__( 'You do not have permission to do that.', 'mmi-tech' ), 403 );
	}

	if ( ! isset( $_POST['mmi_dashboard_nonce'] ) || ! wp_verify_nonce( $_POST['mmi_dashboard_nonce'], 'mmi_dashboard_action' ) ) {
		wp_die( esc_html__( 'Your session expired. Please go back and try again.', 'mmi-tech' ), 403 );
	}

	$redirect_tab    = isset( $_POST['mmi_tab'] ) ? sanitize_key( $_POST['mmi_tab'] ) : 'enquiries';
	$redirect_notice = 'ok';

	switch ( $form ) {

		case 'dashboard_status':
			$enquiry_id = isset( $_POST['mmi_enquiry_id'] ) ? absint( $_POST['mmi_enquiry_id'] ) : 0;
			$status     = isset( $_POST['mmi_status'] ) ? sanitize_key( $_POST['mmi_status'] ) : 'pending';
			if ( $enquiry_id && 'mmi_enquiry' === get_post_type( $enquiry_id ) ) {
				mmi_set_enquiry_status( $enquiry_id, $status );
			}
			break;

		case 'dashboard_reply':
			$enquiry_id = isset( $_POST['mmi_enquiry_id'] ) ? absint( $_POST['mmi_enquiry_id'] ) : 0;
			$reply      = isset( $_POST['mmi_reply_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['mmi_reply_message'] ) ) : '';

			if ( $enquiry_id && 'mmi_enquiry' === get_post_type( $enquiry_id ) && '' !== $reply ) {
				$to = mmi_get_enquiry_field( $enquiry_id, 'email' );

				if ( $to && is_email( $to ) ) {
					$staff_user = wp_get_current_user();
					$subject    = __( 'Re: Your enquiry to MMI Technologies Ltd', 'mmi-tech' );
					$sent       = wp_mail( $to, $subject, $reply );

					// Log the reply as a comment thread on the enquiry, whether
					// or not the email itself succeeded, so there's always a
					// record of what was said.
					wp_insert_comment( array(
						'comment_post_ID'      => $enquiry_id,
						'comment_content'      => $reply,
						'comment_type'         => 'mmi_staff_reply',
						'comment_approved'     => 1,
						'user_id'              => $staff_user->ID,
						'comment_author'       => $staff_user->display_name,
						'comment_author_email' => $staff_user->user_email,
					) );

					mmi_set_enquiry_status( $enquiry_id, 'responded' );
					$redirect_notice = $sent ? 'replied' : 'reply-logged-not-sent';
				} else {
					$redirect_notice = 'no-email';
				}
			}
			break;

		case 'dashboard_comment':
			$comment_id     = isset( $_POST['mmi_comment_id'] ) ? absint( $_POST['mmi_comment_id'] ) : 0;
			$comment_action = isset( $_POST['mmi_comment_action'] ) ? sanitize_key( $_POST['mmi_comment_action'] ) : '';

			if ( $comment_id && current_user_can( 'moderate_comments' ) ) {
				switch ( $comment_action ) {
					case 'approve':
						wp_set_comment_status( $comment_id, 'approve' );
						break;
					case 'unapprove':
						wp_set_comment_status( $comment_id, 'hold' );
						break;
					case 'spam':
						wp_spam_comment( $comment_id );
						break;
					case 'trash':
						wp_trash_comment( $comment_id );
						break;
					case 'reply':
						$reply_text = isset( $_POST['mmi_comment_reply_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['mmi_comment_reply_message'] ) ) : '';
						$parent     = get_comment( $comment_id );
						if ( $reply_text && $parent ) {
							$staff_user = wp_get_current_user();
							wp_insert_comment( array(
								'comment_post_ID'      => $parent->comment_post_ID,
								'comment_parent'       => $comment_id,
								'comment_content'      => $reply_text,
								'comment_approved'     => 1,
								'user_id'              => $staff_user->ID,
								'comment_author'       => $staff_user->display_name,
								'comment_author_email' => $staff_user->user_email,
							) );
						}
						break;
				}
			}
			break;
	}

	wp_safe_redirect( add_query_arg( array(
		'mmi_tab'    => $redirect_tab,
		'mmi_notice' => $redirect_notice,
	), mmi_get_staff_dashboard_url() ) );
	exit;
}
add_action( 'template_redirect', 'mmi_dashboard_handle_actions' );
