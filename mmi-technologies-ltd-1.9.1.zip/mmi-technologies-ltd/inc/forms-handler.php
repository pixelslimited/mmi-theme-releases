<?php
/**
 * Contact form handling.
 *
 * IMPORTANT — v1.7.0 fix: the visitor's name field is submitted as
 * "mmi_name", NOT "name". WordPress reserves "name" as a built-in public
 * query var (used to look up a post/page by its URL slug). If a front-end
 * form POSTs a field literally called "name", WP's own request parser
 * (WP::parse_request()) overwrites the query var it already resolved from
 * the URL with that POSTed value, WordPress then fails to find any post
 * with that "slug", and the ENTIRE request — including the page you're
 * submitting to — comes back as a 404, even though nothing is actually
 * wrong with the form or this handler. Do not rename this field back to
 * "name" (or to any other reserved query var such as "page", "author",
 * "cat", "tag", "search", "feed", "preview", "embed", etc.).
 *
 * @package MMI_Technologies
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A private, admin-only log of every enquiry submitted — this is the
 * permanent record of a submission. It is written BEFORE any email attempt,
 * so an enquiry is never lost even if outgoing mail fails or isn't
 * available on the host at all.
 */
function mmi_register_enquiry_log() {
	register_post_type( 'mmi_enquiry', array(
		'labels' => array(
			'name'          => __( 'Enquiries', 'mmi-tech' ),
			'singular_name' => __( 'Enquiry', 'mmi-tech' ),
			'all_items'     => __( 'Enquiries', 'mmi-tech' ),
			'view_item'     => __( 'View Enquiry', 'mmi-tech' ),
			'search_items'  => __( 'Search Enquiries', 'mmi-tech' ),
			'not_found'     => __( 'No enquiries yet', 'mmi-tech' ),
			'menu_name'     => __( 'Enquiries', 'mmi-tech' ),
		),
		'public'             => false,
		'publicly_queryable' => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_icon'          => 'dashicons-email-alt',
		'menu_position'      => 25,
		'supports'           => array( 'title', 'editor' ),
		'show_in_rest'       => false,
		// Explicitly no rewrite/front-end presence at all for this log type.
		'rewrite'            => false,
		'has_archive'        => false,
	) );
}
add_action( 'init', 'mmi_register_enquiry_log' );

/**
 * Write one enquiry to the log, saving both the readable body AND structured
 * post meta (name/email/phone/service/status) so the staff dashboard can
 * work with the data directly instead of re-parsing text.
 */
function mmi_log_enquiry( $subject, $body, $fields = array() ) {
	$enquiry_id = wp_insert_post( array(
		'post_type'    => 'mmi_enquiry',
		'post_status'  => 'private',
		'post_title'   => $subject,
		'post_content' => $body,
	), true );

	if ( is_wp_error( $enquiry_id ) || ! $enquiry_id ) {
		return $enquiry_id;
	}

	if ( isset( $fields['name'] ) ) {
		update_post_meta( $enquiry_id, '_mmi_enquiry_name', $fields['name'] );
	}
	if ( isset( $fields['email'] ) ) {
		update_post_meta( $enquiry_id, '_mmi_enquiry_email', $fields['email'] );
	}
	if ( isset( $fields['phone'] ) ) {
		update_post_meta( $enquiry_id, '_mmi_enquiry_phone', $fields['phone'] );
	}
	if ( isset( $fields['service'] ) ) {
		update_post_meta( $enquiry_id, '_mmi_enquiry_service', $fields['service'] );
	}
	update_post_meta( $enquiry_id, '_mmi_enquiry_status', 'pending' );

	return $enquiry_id;
}

/* -------------------------------------------------------------------------
 * Enquiry meta accessors (used by the staff dashboard too).
 * ---------------------------------------------------------------------- */

function mmi_get_enquiry_field( $enquiry_id, $field ) {
	return get_post_meta( $enquiry_id, '_mmi_enquiry_' . $field, true );
}

function mmi_get_enquiry_status( $enquiry_id ) {
	$status = get_post_meta( $enquiry_id, '_mmi_enquiry_status', true );
	return in_array( $status, array( 'responded', 'pending' ), true ) ? $status : 'pending';
}

function mmi_get_enquiry_status_label( $enquiry_id ) {
	return 'responded' === mmi_get_enquiry_status( $enquiry_id )
		? __( 'Responded', 'mmi-tech' )
		: __( 'Not Responded', 'mmi-tech' );
}

function mmi_set_enquiry_status( $enquiry_id, $status ) {
	$status = in_array( $status, array( 'responded', 'pending' ), true ) ? $status : 'pending';
	update_post_meta( $enquiry_id, '_mmi_enquiry_status', $status );
}

/**
 * Build a one-tap WhatsApp link (wa.me) pre-filled with an enquiry's full
 * details, addressed to the BUSINESS's own WhatsApp number (the same number
 * configured under Appearance > Customize > MMI Brand Settings > WhatsApp
 * Number — see mmi_whatsapp_url() in inc/customizer.php). Nothing is sent
 * automatically: WhatsApp itself requires a human to tap the link and press
 * Send, so this is a "forward with one tap" convenience, not a silent
 * auto-send. Works with no extra account, API, or cost.
 */
function mmi_get_enquiry_whatsapp_url( $enquiry_id ) {
	if ( ! function_exists( 'mmi_whatsapp_url' ) ) {
		return '';
	}

	$name    = mmi_get_enquiry_field( $enquiry_id, 'name' );
	$email   = mmi_get_enquiry_field( $enquiry_id, 'email' );
	$phone   = mmi_get_enquiry_field( $enquiry_id, 'phone' );
	$service = mmi_get_enquiry_field( $enquiry_id, 'service' );
	$post    = get_post( $enquiry_id );
	$message = $post ? $post->post_content : '';

	// The enquiry body already contains Name/Phone/Email/Service/Message in
	// a readable layout — reuse it directly so this stays in sync with
	// whatever mmi_handle_contact_form() builds, and just add a short lead-in
	// line so it's clearly identifiable as a forwarded website enquiry.
	$text = sprintf(
		/* translators: %s: enquirer's name. */
		__( "New website enquiry from %s:\n\n", 'mmi-tech' ),
		$name ? $name : __( 'a visitor', 'mmi-tech' )
	);
	$text .= $message ? $message : trim(
		"Name: {$name}\nPhone: {$phone}\nEmail: {$email}\nService: {$service}"
	);

	return mmi_whatsapp_url( $text );
}

/**
 * Build a stable per-visitor key (no cookies required) so we can show a
 * one-time flash notice after the redirect-free form submission.
 */
function mmi_visitor_key() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : '';
	return md5( $ip . '|' . $ua );
}

/**
 * Handle the Contact form submission.
 */
function mmi_handle_contact_form() {
	if ( empty( $_POST['mmi_form'] ) || 'contact' !== $_POST['mmi_form'] ) {
		return;
	}

	// Nonce check.
	if ( ! isset( $_POST['mmi_contact_nonce'] ) || ! wp_verify_nonce( $_POST['mmi_contact_nonce'], 'mmi_contact_submit' ) ) {
		set_transient( 'mmi_form_notice_' . mmi_visitor_key(), array(
			'type'    => 'error',
			'message' => __( 'Your session expired before the form could be submitted. Please try again.', 'mmi-tech' ),
		), 60 );
		return;
	}

	// Honeypot — real visitors never fill this hidden field in.
	if ( ! empty( $_POST['mmi_website'] ) ) {
		return;
	}

	$name    = isset( $_POST['mmi_name'] ) ? sanitize_text_field( wp_unslash( $_POST['mmi_name'] ) ) : '';
	$phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$service = isset( $_POST['service'] ) ? sanitize_text_field( wp_unslash( $_POST['service'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

	if ( '' === $name || '' === $email || '' === $message || ! is_email( $email ) ) {
		set_transient( 'mmi_form_notice_' . mmi_visitor_key(), array(
			'type'    => 'error',
			'message' => __( 'Please fill in your name, a valid email address, and a message before sending.', 'mmi-tech' ),
		), 60 );
		return;
	}

	$subject = sprintf( '[Enquiry] %s — %s', $name, $service ? $service : __( 'General', 'mmi-tech' ) );
	$body    = "Name: {$name}\nPhone: {$phone}\nEmail: {$email}\nService: {$service}\n\nMessage:\n{$message}";

	// Always log first — this is the record of the enquiry regardless of
	// whether outgoing email works on this host.
	$enquiry_id = mmi_log_enquiry( $subject, $body, array(
		'name'    => $name,
		'email'   => $email,
		'phone'   => $phone,
		'service' => $service,
	) );

	// Build the email body with a one-tap "forward to WhatsApp" link appended
	// so whoever reads the notification email can forward the full enquiry
	// to the business WhatsApp number with a single tap, no retyping needed.
	$email_body = $body;
	if ( $enquiry_id && ! is_wp_error( $enquiry_id ) ) {
		$whatsapp_url = mmi_get_enquiry_whatsapp_url( $enquiry_id );
		if ( $whatsapp_url ) {
			$email_body .= "\n\n-----\n" . __( 'Forward this enquiry to WhatsApp with one tap:', 'mmi-tech' ) . "\n" . $whatsapp_url;
		}
	}

	// Only attempt email if we have a real way to send it: either PHP's
	// mail() function exists on this host, OR SMTP delivery has been
	// configured and enabled under Settings > MMI Email (which sends over
	// its own SMTP connection and does not depend on mail() at all).
	$sent = false;
	if ( function_exists( 'mail' ) || ( function_exists( 'mmi_smtp_is_enabled' ) && mmi_smtp_is_enabled() ) ) {
		$to      = function_exists( 'mmi_get_notification_email' ) ? mmi_get_notification_email() : get_option( 'admin_email' );
		$headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );
		$sent    = wp_mail( $to, $subject, $email_body, $headers );
	}

	if ( $sent ) {
		$message_text = __( 'Thank you — your enquiry has been sent. We will respond as soon as possible.', 'mmi-tech' );
	} else {
		$message_text = __( 'Thank you — your enquiry has been received and logged. For a faster response, you can also reach us directly on WhatsApp.', 'mmi-tech' );
	}

	set_transient( 'mmi_form_notice_' . mmi_visitor_key(), array(
		'type'    => 'success',
		'message' => $message_text,
	), 60 );
}
add_action( 'template_redirect', 'mmi_handle_contact_form' );

/**
 * Output (and clear) any pending flash notice for the current visitor.
 * Called near the top of template-contact.php.
 */
function mmi_form_notice() {
	$key    = 'mmi_form_notice_' . mmi_visitor_key();
	$notice = get_transient( $key );
	if ( ! $notice ) {
		return;
	}
	delete_transient( $key );
	$type = ( isset( $notice['type'] ) && 'error' === $notice['type'] ) ? 'error' : 'success';
	printf(
		'<div class="mmi-form-notice mmi-form-notice-%1$s">%2$s</div>',
		esc_attr( $type ),
		esc_html( $notice['message'] )
	);
}
