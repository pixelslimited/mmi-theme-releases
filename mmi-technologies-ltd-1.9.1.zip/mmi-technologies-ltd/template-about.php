<?php
/**
 * Template Name: About Page
 *
 * @package MMI_Technologies
 */
get_header();
?>

<section class="page-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<?php mmi_breadcrumbs(); ?>
	</div>
</section>

<main class="mmi-about">
	<div class="container">
		<?php
		while ( have_posts() ) :
			the_post();
			if ( get_the_content() ) :
				?>
				<div class="mmi-post-content"><?php the_content(); ?></div>
				<?php
			endif;
		endwhile;
		?>

		<div class="about-mission-grid">
			<div class="about-mission-card">
				<h2><?php esc_html_e( 'Our Vision', 'mmi-tech' ); ?></h2>
				<p><?php esc_html_e( 'To be a leading provider of innovative technology and power solutions across Nigeria and beyond, recognized for reliability, quality and sustainable impact.', 'mmi-tech' ); ?></p>
			</div>
			<div class="about-mission-card">
				<h2><?php esc_html_e( 'Our Mission', 'mmi-tech' ); ?></h2>
				<p><?php esc_html_e( 'To deliver dependable solar power, security, networking, IT, construction, supply and consultancy services that empower our clients and communities, backed by technical excellence and strong partnerships.', 'mmi-tech' ); ?></p>
			</div>
		</div>

		<div class="section-heading">
			<h2><?php esc_html_e( 'Our Core Values', 'mmi-tech' ); ?></h2>
		</div>
		<div class="core-values-grid">
			<?php
			$values = array(
				array( 'icon' => 'innovation', 'title' => __( 'Innovation', 'mmi-tech' ) ),
				array( 'icon' => 'check', 'title' => __( 'Integrity', 'mmi-tech' ) ),
				array( 'icon' => 'eco', 'title' => __( 'Sustainability', 'mmi-tech' ) ),
				array( 'icon' => 'consultancy', 'title' => __( 'Customer Focus', 'mmi-tech' ) ),
				array( 'icon' => 'diversify', 'title' => __( 'Excellence', 'mmi-tech' ) ),
				array( 'icon' => 'network', 'title' => __( 'Partnership', 'mmi-tech' ) ),
			);
			foreach ( $values as $value ) :
				?>
				<div class="core-value-card">
					<span class="core-value-icon"><?php mmi_icon( $value['icon'] ); ?></span>
					<h3><?php echo esc_html( $value['title'] ); ?></h3>
				</div>
				<?php
			endforeach;
			?>
		</div>
	</div>
</main>

<?php get_footer(); ?>
