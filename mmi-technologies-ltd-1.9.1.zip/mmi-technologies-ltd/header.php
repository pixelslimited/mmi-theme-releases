<?php
/**
 * The header for the theme.
 *
 * @package MMI_Technologies
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#0B7FE0">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="top-bar">
	<div class="container top-bar-inner">
		<div class="top-bar-contact">
			<a href="tel:+2347019448554"><?php mmi_icon( 'phone' ); ?> +234 701 944 8554</a>
			<a href="mailto:mmitechnologies1@gmail.com"><?php mmi_icon( 'mail' ); ?> mmitechnologies1@gmail.com</a>
		</div>
		<div class="top-bar-hours">
			<span><?php mmi_icon( 'clock' ); ?> Mon &ndash; Sat: 9:00 AM &ndash; 5:30 PM</span>
		</div>
	</div>
</div>

<header class="site-header" id="site-header">
	<div class="container site-header-inner">
		<div class="site-logo-lockup">
			<?php the_custom_logo(); ?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-title-link">
				<span class="site-title"><?php bloginfo( 'name' ); ?></span>
				<span class="site-tagline"><?php echo esc_html( get_theme_mod( 'mmi_header_tagline', 'Innovation is our tradition' ) ); ?></span>
			</a>
		</div>

		<nav class="primary-nav" id="primary-nav" aria-label="<?php esc_attr_e( 'Primary Menu', 'mmi-tech' ); ?>">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu( array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'primary-menu',
					'fallback_cb'    => false,
				) );
			} else {
				?>
				<ul class="primary-menu">
					<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
					<li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">About</a></li>
					<li><a href="<?php echo esc_url( home_url( '/services/' ) ); ?>">Services</a></li>
					<li><a href="<?php echo esc_url( home_url( '/products/' ) ); ?>">Products</a></li>
					<li><a href="<?php echo esc_url( home_url( '/projects/' ) ); ?>">Projects</a></li>
					<li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact Us</a></li>
				</ul>
				<?php
			}
			?>
		</nav>

		<div class="site-header-actions">
			<a href="<?php echo esc_url( mmi_get_contact_page_url() ); ?>" class="btn btn-primary btn-quote"><?php esc_html_e( 'Get a Quote', 'mmi-tech' ); ?></a>
			<button type="button" class="mobile-nav-toggle" id="mobile-nav-toggle" aria-expanded="false" aria-controls="primary-nav">
				<span></span><span></span><span></span>
				<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'mmi-tech' ); ?></span>
			</button>
		</div>
	</div>
</header>

<a href="<?php echo esc_url( mmi_whatsapp_url() ); ?>" class="whatsapp-float" target="_blank" rel="noopener" aria-label="<?php esc_attr_e( 'Chat on WhatsApp', 'mmi-tech' ); ?>">
	<svg viewBox="0 0 32 32" width="28" height="28" fill="currentColor"><path d="M16.02 3C9.4 3 4 8.4 4 15.02c0 2.4.68 4.66 1.86 6.58L4 29l7.56-1.8a11.97 11.97 0 004.46.86h.01c6.62 0 12.02-5.4 12.02-12.02C28.05 8.4 22.65 3 16.02 3zm0 21.86c-1.5 0-2.96-.4-4.24-1.16l-.3-.18-4.48 1.07 1.2-4.36-.2-.32a9.83 9.83 0 01-1.5-5.19c0-5.44 4.42-9.86 9.86-9.86a9.8 9.8 0 016.98 2.88 9.8 9.8 0 012.88 6.98c0 5.44-4.42 9.86-9.86 9.86zm5.4-7.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.65-2.05-.17-.3-.02-.46.13-.6.14-.14.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48 0 1.46 1.07 2.87 1.22 3.07.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.63.71.23 1.36.2 1.87.12.57-.08 1.76-.72 2.01-1.42.25-.7.25-1.3.17-1.42-.07-.13-.27-.2-.57-.35z"/></svg>
</a>
