<?php
/**
 * Single Project template.
 *
 * @package MMI_Technologies
 */
get_header();

while ( have_posts() ) :
	the_post();

	$post_id  = get_the_ID();
	$type     = mmi_get_project_type( $post_id );
	$location = mmi_get_project_location( $post_id );

	$image_ids = array();
	if ( has_post_thumbnail() ) {
		$image_ids[] = get_post_thumbnail_id();
	}
	$image_ids = array_merge( $image_ids, mmi_get_gallery_ids( $post_id, '_mmi_project_gallery' ) );
	$image_ids = array_unique( $image_ids );
	?>

	<section class="page-hero page-hero-sm">
		<div class="container">
			<?php mmi_breadcrumbs(); ?>
		</div>
	</section>

	<main class="mmi-single-item">
		<div class="container item-detail-grid">

			<div class="mmi-item-gallery">
				<?php if ( ! empty( $image_ids ) ) : ?>
					<?php
					$first     = array_shift( $image_ids );
					$first_src = wp_get_attachment_image_src( $first, 'large' );
					?>
					<div class="mmi-gallery-main">
						<img src="<?php echo esc_url( $first_src[0] ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>">
					</div>
					<?php if ( ! empty( $image_ids ) ) : ?>
						<div class="mmi-gallery-thumbs">
							<button type="button" class="mmi-gallery-thumb is-active" data-full="<?php echo esc_url( $first_src[0] ); ?>" data-alt="<?php echo esc_attr( get_the_title() ); ?>">
								<img src="<?php echo esc_url( wp_get_attachment_image_url( $first, 'mmi-gallery-thumb' ) ); ?>" alt="">
							</button>
							<?php foreach ( $image_ids as $img_id ) : ?>
								<?php $full = wp_get_attachment_image_src( $img_id, 'large' ); ?>
								<button type="button" class="mmi-gallery-thumb" data-full="<?php echo esc_url( $full[0] ); ?>" data-alt="<?php echo esc_attr( get_the_title() ); ?>">
									<img src="<?php echo esc_url( wp_get_attachment_image_url( $img_id, 'mmi-gallery-thumb' ) ); ?>" alt="">
								</button>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				<?php else : ?>
					<div class="mmi-gallery-main">
						<span class="media-placeholder media-placeholder-lg"><?php mmi_icon( 'project' ); ?></span>
					</div>
				<?php endif; ?>
			</div>

			<div class="mmi-item-info">
				<h1><?php the_title(); ?></h1>

				<?php if ( $type || $location ) : ?>
					<div class="project-meta-row project-meta-row-lg">
						<?php if ( $type ) : ?>
							<span class="project-meta-tag"><?php mmi_icon( 'project' ); ?><?php echo esc_html( $type ); ?></span>
						<?php endif; ?>
						<?php if ( $location ) : ?>
							<span class="project-meta-tag"><?php mmi_icon( 'pin' ); ?><?php echo esc_html( $location ); ?></span>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<?php if ( get_the_content() ) : ?>
					<div class="mmi-post-content"><?php the_content(); ?></div>
				<?php endif; ?>

				<div class="mmi-item-cta">
					<a href="<?php echo esc_url( mmi_get_contact_page_url() ); ?>" class="btn btn-primary btn-lg"><?php esc_html_e( 'Discuss a Similar Project', 'mmi-tech' ); ?></a>
					<a href="<?php echo esc_url( mmi_whatsapp_url() ); ?>" class="btn btn-outline btn-lg" target="_blank" rel="noopener"><?php esc_html_e( 'WhatsApp Us', 'mmi-tech' ); ?></a>
				</div>
			</div>
		</div>

		<div class="container">
			<a href="<?php echo esc_url( mmi_get_projects_page_url() ); ?>" class="mmi-back-link"><?php mmi_icon( 'arrow' ); ?> <?php esc_html_e( 'Back to All Projects', 'mmi-tech' ); ?></a>
		</div>
	</main>

	<?php
endwhile;

get_footer();
