/**
 * Admin: multi-image gallery picker for the Product / Project meta boxes.
 * Uses the standard wp.media() frame. Requires jQuery + wp_enqueue_media().
 */
( function ( $ ) {
	'use strict';

	$( function () {
		$( '.mmi-gallery-field' ).each( function () {
			var $field = $( this );
			var $hiddenInput = $field.find( '.mmi-gallery-ids' );
			var $preview = $field.find( '.mmi-gallery-preview' );
			var $addButton = $field.find( '.mmi-gallery-add' );
			var frame;

			function getIds() {
				var raw = $hiddenInput.val();
				if ( ! raw ) {
					return [];
				}
				return raw.split( ',' ).filter( function ( v ) {
					return v !== '';
				} ).map( function ( v ) {
					return parseInt( v, 10 );
				} );
			}

			function setIds( ids ) {
				$hiddenInput.val( ids.join( ',' ) );
			}

			function addThumb( attachment ) {
				var thumbUrl = attachment.sizes && attachment.sizes.thumbnail
					? attachment.sizes.thumbnail.url
					: attachment.url;

				var $item = $(
					'<div class="mmi-gallery-item" data-id="' + attachment.id + '" style="position:relative;">' +
						'<img src="' + thumbUrl + '" style="width:80px;height:80px;object-fit:cover;border-radius:4px;border:1px solid #ddd;">' +
						'<button type="button" class="mmi-gallery-remove" style="position:absolute;top:-8px;right:-8px;background:#d63638;color:#fff;border:none;border-radius:50%;width:20px;height:20px;line-height:18px;cursor:pointer;">&times;</button>' +
					'</div>'
				);
				$preview.append( $item );
			}

			$addButton.on( 'click', function ( e ) {
				e.preventDefault();

				if ( frame ) {
					frame.open();
					return;
				}

				frame = wp.media( {
					title: 'Select Images',
					button: { text: 'Add to Gallery' },
					multiple: true
				} );

				frame.on( 'select', function () {
					var selection = frame.state().get( 'selection' );
					var ids = getIds();

					selection.each( function ( attachment ) {
						var data = attachment.toJSON();
						if ( ids.indexOf( data.id ) === -1 ) {
							ids.push( data.id );
							addThumb( data );
						}
					} );

					setIds( ids );
				} );

				frame.open();
			} );

			$preview.on( 'click', '.mmi-gallery-remove', function () {
				var $item = $( this ).closest( '.mmi-gallery-item' );
				var removeId = parseInt( $item.data( 'id' ), 10 );
				var ids = getIds().filter( function ( id ) {
					return id !== removeId;
				} );
				setIds( ids );
				$item.remove();
			} );
		} );
	} );
} )( jQuery );
