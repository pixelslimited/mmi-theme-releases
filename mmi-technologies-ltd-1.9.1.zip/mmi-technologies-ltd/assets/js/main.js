/**
 * MMI Technologies Ltd — front-end behaviour.
 * Vanilla JS, no dependencies.
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		initMobileNav();
		initHeaderScrollState();
		initGalleryThumbs();
		initImageSkeletons();
		initFormLoadingStates();
		initScrollReveal();
	} );

	/**
	 * Best-effort check for a slow/constrained connection, using the Network
	 * Information API where the browser supports it (most Chromium-based
	 * mobile browsers; Safari does not expose this, so this simply returns
	 * false there and skeletons are skipped — a reasonable default since
	 * iOS/Safari users are rarely the ones on a struggling 2G/3G link).
	 * Returns false (never throws) on any browser that lacks the API.
	 */
	function mmiIsSlowConnection() {
		try {
			var c = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
			if ( ! c ) {
				return false;
			}
			if ( c.saveData ) {
				return true;
			}
			if ( c.effectiveType && /2g/.test( c.effectiveType ) ) {
				return true;
			}
			if ( typeof c.downlink === 'number' && c.downlink > 0 && c.downlink < 1.5 ) {
				return true;
			}
			return false;
		} catch ( e ) {
			return false;
		}
	}

	/**
	 * Skeleton shimmer on images — ONLY while the connection looks slow.
	 * On a normal connection this does nothing: images load fast enough that
	 * a skeleton would just be flicker, not a help. mmi-card-media and the
	 * gallery containers are already position:relative/overflow:hidden, so a
	 * skeleton can be toggled on the existing container with no markup
	 * changes to any template.
	 */
	function initImageSkeletons() {
		if ( ! mmiIsSlowConnection() ) {
			return;
		}
		var containers = document.querySelectorAll( '.mmi-card-media, .mmi-gallery-main, .mmi-gallery-thumb' );
		containers.forEach( function ( container ) {
			var img = container.querySelector( 'img' );
			if ( ! img ) {
				return;
			}
			if ( img.complete && img.naturalWidth > 0 ) {
				return; // Already loaded (e.g. from cache) — nothing to show.
			}
			container.classList.add( 'mmi-skeleton-loading' );
			var clear = function () {
				container.classList.remove( 'mmi-skeleton-loading' );
			};
			img.addEventListener( 'load', clear, { once: true } );
			img.addEventListener( 'error', clear, { once: true } );
		} );
	}

	/**
	 * Every form submission gets an immediate loading state on its submit
	 * button — a spinner plus a disabled state — the instant it's sent,
	 * regardless of connection speed. These are classic (non-AJAX) POST
	 * forms that navigate to a new page, so this isn't about waiting for a
	 * fetch(); it's instant feedback that the tap/click registered and
	 * guards against a double-submit while the next page loads.
	 */
	function initFormLoadingStates() {
		var forms = document.querySelectorAll( 'form' );
		forms.forEach( function ( form ) {
			form.addEventListener( 'submit', function () {
				var btn = form.querySelector( 'button[type="submit"], input[type="submit"]' );
				if ( ! btn || btn.disabled ) {
					return;
				}
				btn.disabled = true;
				btn.classList.add( 'is-loading' );
				if ( btn.tagName === 'BUTTON' ) {
					btn.dataset.mmiOriginalHtml = btn.innerHTML;
					btn.innerHTML = '<span class="mmi-spinner" aria-hidden="true"></span> ' + ( btn.textContent || '' ).trim();
				}
			} );
		} );
	}

	/**
	 * Fade/lift sections and cards into view as they scroll into the
	 * viewport. Purely a progressive enhancement: the "ready" class that
	 * hides elements pre-reveal is only added once we know
	 * IntersectionObserver is available AND the visitor hasn't asked for
	 * reduced motion, so content is never hidden behind JS that might not
	 * run.
	 */
	function initScrollReveal() {
		if ( ! ( 'IntersectionObserver' in window ) ) {
			return;
		}
		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			return;
		}
		var targets = document.querySelectorAll( '.mmi-reveal' );
		if ( ! targets.length ) {
			return;
		}
		document.documentElement.classList.add( 'mmi-reveal-ready' );
		var observer = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( entry.isIntersecting ) {
					entry.target.classList.add( 'is-visible' );
					observer.unobserve( entry.target );
				}
			} );
		}, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 } );
		targets.forEach( function ( target ) {
			observer.observe( target );
		} );
	}

	/**
	 * Mobile nav toggle.
	 */
	function initMobileNav() {
		var toggle = document.getElementById( 'mobile-nav-toggle' );
		var nav = document.getElementById( 'primary-nav' );
		if ( ! toggle || ! nav ) {
			return;
		}
		toggle.addEventListener( 'click', function () {
			var isOpen = nav.classList.toggle( 'is-open' );
			toggle.classList.toggle( 'is-active', isOpen );
			toggle.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
		} );

		// Close the mobile menu after a link is tapped.
		nav.addEventListener( 'click', function ( e ) {
			if ( e.target.tagName === 'A' ) {
				nav.classList.remove( 'is-open' );
				toggle.classList.remove( 'is-active' );
				toggle.setAttribute( 'aria-expanded', 'false' );
			}
		} );
	}

	/**
	 * Toggle a subtle gradient stripe under the header once the page scrolls.
	 */
	function initHeaderScrollState() {
		var header = document.getElementById( 'site-header' );
		if ( ! header ) {
			return;
		}
		var onScroll = function () {
			if ( window.scrollY > 12 ) {
				header.classList.add( 'is-scrolled' );
			} else {
				header.classList.remove( 'is-scrolled' );
			}
		};
		onScroll();
		window.addEventListener( 'scroll', onScroll, { passive: true } );
	}

	/**
	 * Product/Project single-page gallery: clicking a thumbnail swaps the
	 * large image and toggles the active state.
	 */
	function initGalleryThumbs() {
		var galleries = document.querySelectorAll( '.mmi-item-gallery' );
		galleries.forEach( function ( gallery ) {
			var mainImg = gallery.querySelector( '.mmi-gallery-main img' );
			var thumbs = gallery.querySelectorAll( '.mmi-gallery-thumb' );
			if ( ! mainImg || ! thumbs.length ) {
				return;
			}
			thumbs.forEach( function ( thumb ) {
				thumb.addEventListener( 'click', function () {
					var full = thumb.getAttribute( 'data-full' );
					var alt = thumb.getAttribute( 'data-alt' );
					if ( full ) {
						mainImg.setAttribute( 'src', full );
					}
					if ( alt ) {
						mainImg.setAttribute( 'alt', alt );
					}
					thumbs.forEach( function ( t ) {
						t.classList.remove( 'is-active' );
					} );
					thumb.classList.add( 'is-active' );
				} );
			} );
		} );
	}
} )();
