/* Small touches for the modern look: header shadow on scroll, soft spotlight that follows the pointer over service cards. */
( function () {
	'use strict';
	var header = document.getElementById( 'site-header' );
	if ( header ) {
		var on = function () { header.classList.toggle( 'is-scrolled', window.scrollY > 24 ); };
		on(); window.addEventListener( 'scroll', on, { passive: true } );
	}
	if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) { return; }
	document.querySelectorAll( '.service-card' ).forEach( function ( c ) {
		c.addEventListener( 'pointermove', function ( e ) {
			var r = c.getBoundingClientRect();
			c.style.setProperty( '--mx', ( e.clientX - r.left ) + 'px' );
			c.style.setProperty( '--my', ( e.clientY - r.top ) + 'px' );
		} );
	} );
}() );
