<?php
/**
 * 404 template.
 *
 * @package MMI_Technologies
 */
get_header();
?>

<main class="mmi-404">
	<div class="container mmi-404-inner">
		<div class="mmi-404-code">404</div>
		<h1><?php esc_html_e( 'Page Not Found', 'mmi-tech' ); ?></h1>
		<p><?php esc_html_e( 'The page you are looking for may have been moved or no longer exists.', 'mmi-tech' ); ?><br><?php esc_html_e( 'Try one of the links below or search the site.', 'mmi-tech' ); ?></p>

		<form role="search" method="get" class="mmi-404-search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<input type="search" name="s" placeholder="<?php esc_attr_e( 'Search this site&hellip;', 'mmi-tech' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>">
			<button type="submit"><?php esc_html_e( 'Search', 'mmi-tech' ); ?></button>
		</form>

		<div class="mmi-404-links">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-primary"><?php esc_html_e( 'Back to Home', 'mmi-tech' ); ?></a>
			<a href="<?php echo esc_url( mmi_get_contact_page_url() ); ?>" class="btn btn-outline"><?php esc_html_e( 'Contact Us', 'mmi-tech' ); ?></a>
		</div>
	</div>
</main>

<?php get_footer(); ?>
