<?php
/**
 * Template Name: Staff Dashboard
 *
 * Front-end dashboard for Staff/Admin accounts: view & respond to Contact
 * form enquiries, and moderate site comments. POST actions are handled in
 * inc/enquiry-dashboard.php (mmi_dashboard_handle_actions(), hooked to
 * template_redirect, which runs and redirects BEFORE this template ever
 * renders) — this file only reads data and prints markup.
 *
 * @package MMI_Technologies
 */

if ( ! mmi_current_user_is_staff() ) {
	wp_safe_redirect( mmi_get_staff_login_url() );
	exit;
}

$active_tab     = isset( $_GET['mmi_tab'] ) && 'comments' === $_GET['mmi_tab'] ? 'comments' : 'enquiries';
$status_filter  = isset( $_GET['mmi_status_filter'] ) ? sanitize_key( $_GET['mmi_status_filter'] ) : 'all';
$notice         = isset( $_GET['mmi_notice'] ) ? sanitize_key( $_GET['mmi_notice'] ) : '';
$current_user   = wp_get_current_user();

$notice_messages = array(
	'ok'                     => array( 'success', __( 'Updated.', 'mmi-tech' ) ),
	'replied'                => array( 'success', __( 'Reply sent and logged.', 'mmi-tech' ) ),
	'reply-logged-not-sent'  => array( 'error', __( 'Reply was logged, but the email could not be sent. Check your SMTP settings under Settings > MMI Email.', 'mmi-tech' ) ),
	'no-email'               => array( 'error', __( 'This enquiry has no email address on file, so a reply could not be sent.', 'mmi-tech' ) ),
);

get_header();
?>

<section class="page-hero page-hero-sm">
	<div class="container mmi-dashboard-header">
		<div>
			<h1><?php esc_html_e( 'Staff Dashboard', 'mmi-tech' ); ?></h1>
			<p><?php printf( esc_html__( 'Signed in as %s', 'mmi-tech' ), esc_html( $current_user->display_name ) ); ?></p>
		</div>
		<a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>" class="btn btn-outline-light"><?php esc_html_e( 'Log Out', 'mmi-tech' ); ?></a>
	</div>
</section>

<main class="mmi-dashboard">
	<div class="container">

		<?php if ( $notice && isset( $notice_messages[ $notice ] ) ) : ?>
			<div class="mmi-form-notice mmi-form-notice-<?php echo esc_attr( $notice_messages[ $notice ][0] ); ?>"><?php echo esc_html( $notice_messages[ $notice ][1] ); ?></div>
		<?php endif; ?>

		<div class="mmi-dashboard-tabs">
			<a href="<?php echo esc_url( add_query_arg( 'mmi_tab', 'enquiries', mmi_get_staff_dashboard_url() ) ); ?>" class="mmi-dashboard-tab<?php echo 'enquiries' === $active_tab ? ' is-active' : ''; ?>"><?php esc_html_e( 'Enquiries', 'mmi-tech' ); ?></a>
			<a href="<?php echo esc_url( add_query_arg( 'mmi_tab', 'comments', mmi_get_staff_dashboard_url() ) ); ?>" class="mmi-dashboard-tab<?php echo 'comments' === $active_tab ? ' is-active' : ''; ?>"><?php esc_html_e( 'Comments', 'mmi-tech' ); ?></a>
		</div>

		<?php if ( 'enquiries' === $active_tab ) : ?>

			<div class="mmi-filter-bar">
				<?php
				$filters = array(
					'all'       => __( 'All', 'mmi-tech' ),
					'pending'   => __( 'Not Responded', 'mmi-tech' ),
					'responded' => __( 'Responded', 'mmi-tech' ),
				);
				foreach ( $filters as $key => $label ) :
					$url = 'all' === $key
						? remove_query_arg( 'mmi_status_filter', add_query_arg( 'mmi_tab', 'enquiries', mmi_get_staff_dashboard_url() ) )
						: add_query_arg( array( 'mmi_tab' => 'enquiries', 'mmi_status_filter' => $key ), mmi_get_staff_dashboard_url() );
					?>
					<a href="<?php echo esc_url( $url ); ?>" class="mmi-filter-pill<?php echo $status_filter === $key ? ' is-active' : ''; ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</div>

			<?php
			$enquiries = mmi_get_enquiries_for_dashboard( $status_filter );

			if ( empty( $enquiries ) ) :
				?>
				<p class="mmi-empty-state"><?php esc_html_e( 'No enquiries here yet.', 'mmi-tech' ); ?></p>
				<?php
			else :
				foreach ( $enquiries as $enquiry ) :
					$eid     = $enquiry->ID;
					$name    = mmi_get_enquiry_field( $eid, 'name' );
					$email   = mmi_get_enquiry_field( $eid, 'email' );
					$phone   = mmi_get_enquiry_field( $eid, 'phone' );
					$service = mmi_get_enquiry_field( $eid, 'service' );
					$status  = mmi_get_enquiry_status( $eid );
					$replies = mmi_get_enquiry_replies( $eid );
					?>
					<details class="mmi-dashboard-item">
						<summary class="mmi-dashboard-item-summary">
							<span class="mmi-dashboard-item-name"><?php echo esc_html( $name ? $name : __( '(no name)', 'mmi-tech' ) ); ?></span>
							<span class="mmi-dashboard-item-meta"><?php echo esc_html( $email ); ?> &middot; <?php echo esc_html( get_the_date( 'M j, Y g:ia', $eid ) ); ?></span>
							<span class="mmi-status-badge mmi-status-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( mmi_get_enquiry_status_label( $eid ) ); ?></span>
						</summary>

						<div class="mmi-dashboard-item-body">
							<dl class="mmi-enquiry-facts">
								<?php if ( $phone ) : ?><div><dt><?php esc_html_e( 'Phone', 'mmi-tech' ); ?></dt><dd><?php echo esc_html( $phone ); ?></dd></div><?php endif; ?>
								<?php if ( $service ) : ?><div><dt><?php esc_html_e( 'Service', 'mmi-tech' ); ?></dt><dd><?php echo esc_html( $service ); ?></dd></div><?php endif; ?>
							</dl>

							<div class="mmi-enquiry-message"><?php echo wpautop( esc_html( $enquiry->post_content ) ); ?></div>

							<?php if ( $replies ) : ?>
								<div class="mmi-reply-thread">
									<h4><?php esc_html_e( 'Replies Sent', 'mmi-tech' ); ?></h4>
									<?php foreach ( $replies as $reply ) : ?>
										<div class="mmi-reply-item">
											<div class="mmi-reply-meta"><?php echo esc_html( $reply->comment_author ); ?> &middot; <?php echo esc_html( mysql2date( 'M j, Y g:ia', $reply->comment_date ) ); ?></div>
											<div class="mmi-reply-content"><?php echo wpautop( esc_html( $reply->comment_content ) ); ?></div>
										</div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>

							<div class="mmi-dashboard-actions">
								<form method="post" action="<?php echo esc_url( mmi_get_staff_dashboard_url() ); ?>" class="mmi-inline-form">
									<input type="hidden" name="mmi_form" value="dashboard_status">
									<input type="hidden" name="mmi_enquiry_id" value="<?php echo esc_attr( $eid ); ?>">
									<input type="hidden" name="mmi_tab" value="enquiries">
									<input type="hidden" name="mmi_status" value="<?php echo 'responded' === $status ? 'pending' : 'responded'; ?>">
									<?php wp_nonce_field( 'mmi_dashboard_action', 'mmi_dashboard_nonce' ); ?>
									<button type="submit" class="btn btn-outline btn-sm">
										<?php echo 'responded' === $status
											? esc_html__( 'Mark as Not Responded', 'mmi-tech' )
											: esc_html__( 'Mark as Responded', 'mmi-tech' ); ?>
									</button>
								</form>

								<?php if ( $email ) : ?>
									<a href="<?php echo esc_url( 'mailto:' . $email ); ?>" class="btn btn-outline btn-sm"><?php esc_html_e( 'Email Directly', 'mmi-tech' ); ?></a>
								<?php endif; ?>

								<?php
								$mmi_wa_url = function_exists( 'mmi_get_enquiry_whatsapp_url' ) ? mmi_get_enquiry_whatsapp_url( $eid ) : '';
								if ( $mmi_wa_url ) :
									?>
									<a href="<?php echo esc_url( $mmi_wa_url ); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-outline btn-sm mmi-btn-whatsapp"><?php esc_html_e( 'Forward via WhatsApp', 'mmi-tech' ); ?></a>
								<?php endif; ?>
							</div>

							<?php if ( $email ) : ?>
								<form method="post" action="<?php echo esc_url( mmi_get_staff_dashboard_url() ); ?>" class="mmi-reply-form">
									<input type="hidden" name="mmi_form" value="dashboard_reply">
									<input type="hidden" name="mmi_enquiry_id" value="<?php echo esc_attr( $eid ); ?>">
									<input type="hidden" name="mmi_tab" value="enquiries">
									<?php wp_nonce_field( 'mmi_dashboard_action', 'mmi_dashboard_nonce' ); ?>
									<label for="mmi_reply_message_<?php echo esc_attr( $eid ); ?>"><?php esc_html_e( 'Send a reply by email', 'mmi-tech' ); ?></label>
									<textarea id="mmi_reply_message_<?php echo esc_attr( $eid ); ?>" name="mmi_reply_message" rows="3" required placeholder="<?php esc_attr_e( 'Type your reply…', 'mmi-tech' ); ?>"></textarea>
									<button type="submit" class="btn btn-primary btn-sm"><?php esc_html_e( 'Send Reply', 'mmi-tech' ); ?></button>
								</form>
							<?php endif; ?>
						</div>
					</details>
					<?php
				endforeach;
			endif;
			?>

		<?php else : ?>

			<?php
			$comments = mmi_get_recent_comments_for_dashboard();

			if ( empty( $comments ) ) :
				?>
				<p class="mmi-empty-state"><?php esc_html_e( 'No comments yet.', 'mmi-tech' ); ?></p>
				<?php
			else :
				foreach ( $comments as $comment ) :
					$c_status = wp_get_comment_status( $comment );
					?>
					<details class="mmi-dashboard-item">
						<summary class="mmi-dashboard-item-summary">
							<span class="mmi-dashboard-item-name"><?php echo esc_html( $comment->comment_author ); ?></span>
							<span class="mmi-dashboard-item-meta"><?php echo esc_html( get_the_title( $comment->comment_post_ID ) ); ?> &middot; <?php echo esc_html( mysql2date( 'M j, Y g:ia', $comment->comment_date ) ); ?></span>
							<span class="mmi-status-badge mmi-status-<?php echo esc_attr( $c_status ); ?>"><?php echo esc_html( ucfirst( $c_status ) ); ?></span>
						</summary>

						<div class="mmi-dashboard-item-body">
							<div class="mmi-enquiry-message"><?php echo wpautop( esc_html( $comment->comment_content ) ); ?></div>

							<div class="mmi-dashboard-actions">
								<?php foreach ( array( 'approve' => __( 'Approve', 'mmi-tech' ), 'unapprove' => __( 'Unapprove', 'mmi-tech' ), 'spam' => __( 'Spam', 'mmi-tech' ), 'trash' => __( 'Trash', 'mmi-tech' ) ) as $action_key => $action_label ) : ?>
									<form method="post" action="<?php echo esc_url( mmi_get_staff_dashboard_url() ); ?>" class="mmi-inline-form">
										<input type="hidden" name="mmi_form" value="dashboard_comment">
										<input type="hidden" name="mmi_comment_id" value="<?php echo esc_attr( $comment->comment_ID ); ?>">
										<input type="hidden" name="mmi_comment_action" value="<?php echo esc_attr( $action_key ); ?>">
										<input type="hidden" name="mmi_tab" value="comments">
										<?php wp_nonce_field( 'mmi_dashboard_action', 'mmi_dashboard_nonce' ); ?>
										<button type="submit" class="btn btn-outline btn-sm"><?php echo esc_html( $action_label ); ?></button>
									</form>
								<?php endforeach; ?>
							</div>

							<form method="post" action="<?php echo esc_url( mmi_get_staff_dashboard_url() ); ?>" class="mmi-reply-form">
								<input type="hidden" name="mmi_form" value="dashboard_comment">
								<input type="hidden" name="mmi_comment_id" value="<?php echo esc_attr( $comment->comment_ID ); ?>">
								<input type="hidden" name="mmi_comment_action" value="reply">
								<input type="hidden" name="mmi_tab" value="comments">
								<?php wp_nonce_field( 'mmi_dashboard_action', 'mmi_dashboard_nonce' ); ?>
								<label for="mmi_comment_reply_<?php echo esc_attr( $comment->comment_ID ); ?>"><?php esc_html_e( 'Reply', 'mmi-tech' ); ?></label>
								<textarea id="mmi_comment_reply_<?php echo esc_attr( $comment->comment_ID ); ?>" name="mmi_comment_reply_message" rows="2" placeholder="<?php esc_attr_e( 'Type a reply…', 'mmi-tech' ); ?>"></textarea>
								<button type="submit" class="btn btn-primary btn-sm"><?php esc_html_e( 'Post Reply', 'mmi-tech' ); ?></button>
							</form>
						</div>
					</details>
					<?php
				endforeach;
			endif;
			?>

		<?php endif; ?>
	</div>
</main>

<?php get_footer(); ?>
