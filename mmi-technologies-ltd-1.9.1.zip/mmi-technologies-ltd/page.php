<?php
/**
 * Default template for a plain WordPress Page (one with no custom
 * "template-*.php" assigned in Page Attributes).
 *
 * @package MMI_Technologies
 */
get_header();
?>
<section class="page-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
	</div>
</section>
<main class="mmi-generic-page">
	<div class="container">
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<div class="mmi-post-content"><?php the_content(); ?></div>
			<?php
		endwhile;
		?>
	</div>
</main>
<?php get_footer(); ?>
