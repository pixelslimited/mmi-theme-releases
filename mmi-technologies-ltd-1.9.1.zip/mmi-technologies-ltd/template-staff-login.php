<?php
/**
 * Template Name: Staff Login
 *
 * Front-end login for the Staff dashboard. Uses WordPress's own wp_signon()
 * for authentication — no custom password handling of any kind.
 *
 * @package MMI_Technologies
 */

// Already logged in with dashboard access? Skip straight to the dashboard.
if ( mmi_current_user_is_staff() ) {
	wp_safe_redirect( mmi_get_staff_dashboard_url() );
	exit;
}

$login_error = '';

if ( ! empty( $_POST['mmi_form'] ) && 'staff_login' === $_POST['mmi_form'] ) {
	if ( ! isset( $_POST['mmi_login_nonce'] ) || ! wp_verify_nonce( $_POST['mmi_login_nonce'], 'mmi_staff_login' ) ) {
		$login_error = __( 'Your session expired. Please try again.', 'mmi-tech' );
	} else {
		$creds = array(
			'user_login'    => isset( $_POST['mmi_staff_username'] ) ? sanitize_user( wp_unslash( $_POST['mmi_staff_username'] ) ) : '',
			'user_password' => isset( $_POST['mmi_staff_password'] ) ? (string) $_POST['mmi_staff_password'] : '',
			'remember'      => ! empty( $_POST['mmi_remember'] ),
		);

		if ( '' === $creds['user_login'] || '' === $creds['user_password'] ) {
			$login_error = __( 'Please enter both your username/email and password.', 'mmi-tech' );
		} else {
			$user = wp_signon( $creds, is_ssl() );

			if ( is_wp_error( $user ) ) {
				$login_error = __( 'Incorrect username or password.', 'mmi-tech' );
			} elseif ( ! user_can( $user, MMI_STAFF_CAP ) ) {
				wp_logout();
				$login_error = __( 'This account does not have dashboard access. Ask an administrator to assign the "Staff" role.', 'mmi-tech' );
			} else {
				wp_safe_redirect( mmi_get_staff_dashboard_url() );
				exit;
			}
		}
	}
}

get_header();
?>

<main class="mmi-staff-auth">
	<div class="container mmi-staff-auth-inner">
		<div class="mmi-staff-auth-card">
			<h1><?php esc_html_e( 'Staff Login', 'mmi-tech' ); ?></h1>
			<p><?php esc_html_e( 'Sign in to manage enquiries and comments.', 'mmi-tech' ); ?></p>

			<?php if ( $login_error ) : ?>
				<div class="mmi-form-notice mmi-form-notice-error"><?php echo esc_html( $login_error ); ?></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( get_permalink() ); ?>" class="mmi-form">
				<input type="hidden" name="mmi_form" value="staff_login">
				<?php wp_nonce_field( 'mmi_staff_login', 'mmi_login_nonce' ); ?>

				<div class="form-field">
					<label for="mmi_staff_username"><?php esc_html_e( 'Username or Email', 'mmi-tech' ); ?></label>
					<input type="text" id="mmi_staff_username" name="mmi_staff_username" required autocomplete="username">
				</div>
				<div class="form-field">
					<label for="mmi_staff_password"><?php esc_html_e( 'Password', 'mmi-tech' ); ?></label>
					<input type="password" id="mmi_staff_password" name="mmi_staff_password" required autocomplete="current-password">
				</div>
				<div class="form-field mmi-staff-remember">
					<label>
						<input type="checkbox" name="mmi_remember" value="1">
						<?php esc_html_e( 'Keep me signed in', 'mmi-tech' ); ?>
					</label>
				</div>

				<button type="submit" class="btn btn-primary btn-lg"><?php esc_html_e( 'Sign In', 'mmi-tech' ); ?></button>
			</form>

			<a class="mmi-staff-lostpw" href="<?php echo esc_url( wp_lostpassword_url( mmi_get_staff_login_url() ) ); ?>"><?php esc_html_e( 'Forgot your password?', 'mmi-tech' ); ?></a>
		</div>
	</div>
</main>

<?php get_footer(); ?>
