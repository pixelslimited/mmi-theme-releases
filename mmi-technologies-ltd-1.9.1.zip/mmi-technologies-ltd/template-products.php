<?php
/**
 * Template Name: Products Page
 *
 * @package MMI_Technologies
 */
get_header();

// NOTE: deliberately "mmi_category", not "category" — WordPress's request
// parser checks $_GET (and $_POST) for anything matching a registered
// public query var and will hijack the main query with it if the name
// collides (see the detailed note at the top of inc/forms-handler.php for
// the same class of bug on the Contact form). "mmi_category" avoids that.
$selected_category = isset( $_GET['mmi_category'] ) ? sanitize_title( wp_unslash( $_GET['mmi_category'] ) ) : '';
$categories         = get_terms( array(
	'taxonomy'   => 'mmi_product_category',
	'hide_empty' => true,
) );
?>

<section class="page-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<?php mmi_breadcrumbs(); ?>
	</div>
</section>

<main class="mmi-products-page">
	<div class="container">
		<?php
		while ( have_posts() ) :
			the_post();
			if ( get_the_content() ) :
				?>
				<div class="mmi-post-content"><?php the_content(); ?></div>
				<?php
			endif;
		endwhile;
		?>

		<?php if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) : ?>
			<div class="mmi-filter-bar">
				<a href="<?php echo esc_url( remove_query_arg( 'mmi_category' ) ); ?>" class="mmi-filter-pill<?php echo '' === $selected_category ? ' is-active' : ''; ?>"><?php esc_html_e( 'All', 'mmi-tech' ); ?></a>
				<?php foreach ( $categories as $cat ) : ?>
					<a href="<?php echo esc_url( add_query_arg( 'mmi_category', $cat->slug ) ); ?>" class="mmi-filter-pill<?php echo $selected_category === $cat->slug ? ' is-active' : ''; ?>"><?php echo esc_html( $cat->name ); ?></a>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php mmi_render_products( array( 'category' => $selected_category ) ); ?>
	</div>
</main>

<?php get_footer(); ?>
